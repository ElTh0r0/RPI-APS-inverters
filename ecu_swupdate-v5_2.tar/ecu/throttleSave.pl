#!/usr/bin/perl

use strict;
use warnings;
use CGI;
use JSON::PP;

print CGI::header();
print "";
print "<html>";
print "<head>";

print "</head>";
print "<body><span style='font-size:12px; font-family: arial;'>";

# the call is throttleSave.pl?pMax=300&inv=x
# we know whether the throttle.cgi was successful when the bool
# throttled in inverterfile == 1
my $query = new CGI;
my $inverter = $query->param('inv');
my $throttle = $query->param('pMax');
my $inv_key = "inv$inverter";  # e.g., inv1
print "throttleSave.pl the received parameters are:\n ";
print "inverter = $inverter throttle=$throttle<br>\n";



#we are going to save as json in settings.txt

my $file = '/var/www/ecu_data/inverters/throtvals.json';

# -------- Load JSON --------
#my $json = JSON->new->pretty->canonical;

my $data = {};

if (-e $file) {                     # check if file exists
    open my $fh, "<", $file or die "Can't open $file: $!";
    local $/;                       # slurp mode
    my $raw = <$fh>;
    close $fh;

    eval { $data = decode_json($raw) };
    if ($@) {
        warn "Invalid JSON in $file, starting fresh.\n";
        $data = {};
    }
}

# * * * * * update the throttlr value
$data->{$inv_key} = $throttle;  

# -------- Write JSON back --------
open my $fh, ">", $file or die "Can't write $file: $!";
print $fh encode_json($data);
close $fh;

print "Updated file written.\n";


# Check if file exists
#if (-e $filename) {
#print "filename exists<br>\n";    
#    open(my $in, '<', $filename) or die "Cannot open $filename: $!";
#    local $/;
#    my $raw_json = <$in>;
#    close $in;
    

#    eval {
#        $data = decode_json($raw_json);
#        1;
#    } or do {
#        die "JSON decode errore: $@";
#    };
#} else {
#    print "File $filename does not exist. Creating new one.\n";
#}


# Add or update inv1
#$data->{$inv_key} = 0 + $throttle;

# Write back the updated JSON
#my $json_string = JSON::PP->new->utf8->encode($data);
#my $json_string = encode_json($data);

#open(my $out, '>', $filename) or die "Cannot write to $filename: $!";
#print $out $json_string;
#close $out;

print "going to run throttle.cgi \n<br>";

# now we call a command that runs throttle.cgi
# Escape values to prevent shell injection (basic safety)
$inv_key =~ s/[^0-9]//g;         # Only digits
$throttle =~ s/[^0-9]//g;        # Only digits

my $sysCmd = "sudo /usr/lib/cgi-bin/ecu/throttle.cgi $inv_key $throttle";
system($sysCmd) == 0 or warn "Failed to run throttle.cgi: $!";

print "HTTP/1.1 200 OK";


