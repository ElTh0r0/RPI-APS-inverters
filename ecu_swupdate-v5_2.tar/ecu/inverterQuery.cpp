// this program works as follows
// the arguments are collected and a command is constructed
// then we call sendCommand
// sendCommand returns an answer that we show in the output
//


#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <errno.h>
#include <iostream>
#include <fstream>
#include <stdbool.h>
#include "RSJparser.tcc"
#include <math.h>
#include <sstream>
#include <iomanip>
#include <pigpio.h>
//#include <nlohmann/json.hpp>  // You need this library
// iclude our own library for the io operations
#include </usr/lib/cgi-bin/ecu/libraries/serial_IO.h>
//using json = nlohmann::json;
using namespace std;


int invType;
int panels[4] ={0,0,0,0};
int which;
int maxPower;
int idx;
int errorcode;
float totalpw; // global as we need to log this
int timespan;
float sigQ;


//#include <fstream>
bool fexists(const std::string& filename) {
  std::ifstream ifile(filename.c_str());
  return (bool)ifile;
}

char *split(char *str, const char *delim)
{
    char* p = new char[254]; //strstr(str, delim);
    //char *p = strstr(str, delim);
    p = strstr(str, delim);
   if (p == NULL)
        return NULL; // delimiter not found
    *p = '\0';                // terminate string after head
    return p + strlen(delim); // return tail substring
}


// *********************************************************
//             D E C O D E     A N S W E R
// *********************************************************
int decodeAnswer() 
{                      
// we get an answer like 
//FE0164010064
//FE0345C43A1000A8
//FE034480001400D3
//FE0345C43A1000A8
//FE6E4481000006013A101414006E008D072000005A408000158215F 
//BFB4DDE041105440FE5020F32B003CF05440FE5020F32B0066604CC0EA3A804D70214050C100FD80ED07A0F32B0056A054F019000641F3
//FE480068ACE8ACE000130103030190604001D1B15 3B66 00000000FEFE3A100E5D

// we tail it from FBFB
    char messageToDecode[512] = {0};
    char s_d[512] = {0};
    uint8_t Message_begin_offset = 0;
    int fault = 0;
    char *tail;

    readZigbee(); //
    strcpy(messageToDecode, inMessage);
    cout << "\n<br>messageToDecode = " << messageToDecode << "\n<br>"<< endl;
    cout << "\n<br>length of messageToDecode = " << strlen(messageToDecode) << "\n<br>" << endl;
    if(!messageToDecode) return 50;

// when we get this FE0164010064 FE034480001400D3
// or               FE0164010064 FE0345C43A1000A8 FE034480001400D3

    if(strstr(messageToDecode,  "FE01640100") == NULL) // answer to AF_DATA_REQUEST 00=success
    {
     cout << "AF_DATA_REQUEST failed\n<br>" << endl;
     fault = 10;    
    } else
    if (strstr(messageToDecode, "FE03448000") == NULL) //  AF_DATA_CONFIRM the 00 byte = success
    {
      cout << "no AF_DATA_CONFIRM\n<br>" << endl;
      fault = 11;
    } else
    if (strstr(messageToDecode, "FE0345C4") == NULL) //  ZDO_SRC_RTG_IND
    {
      cout << "no route receipt\n<br>" << endl;
      fault=12; // this command seems facultative
    } else 
    // if both 4481 (AF_INCOMING_MESSAGE) and 4480 (AD_DATA_CONFIRM)  n0t exist the command fails
    if (strstr(messageToDecode, "4481") == NULL)
    {
      cout << "no  AF_INCOMING_MSG and no AF_DATA_CONFIRM\n<br>" << endl;
      fault=13;
    }

    if(fault > 9 ) { 
      return fault;
    }
    //tail the message
    tail = split(messageToDecode, "FBFB"); // remove the 0000 as well
    cout << "message split after FBFB (payload) " << tail << "\n<br>" << endl;
    //the tail ==      
    if(invType != 2) {
    // we know the tail is 

    //BFB4DDE041105440FE5020F32B003CF05440FE5020F32B0066604CC0EA3A804D70214050C100FD80ED07A0F32B0056A054F019000641F3
    //FE480068ACE8ACE000130103030190604001D1B15 3B66 00000000FEFE3A100E5D
    char target[5] ={"3B66"};

    char *ptr = strstr(tail, target); // find "3B66"
    if (ptr != NULL && ptr - tail >= 4) {
        char before[5];
        strncpy(before, ptr - 4, 4);
        before[4] = '\0';
        int decimalValue = (int)strtol(before, NULL, 16) / 28.89; // convert from hex string to int
        //double result = decimalValue / 28.89;
        cout <<"power value YC600 =0x" << before << " that is decimal " << decimalValue << "\n<br>" << endl;
        } else {
        cout << "'3B66' not found or not enough characters before it.\n<br>" << endl;
       }

    }  else {// end if(invType != 2)
       // invType=1
       char powval[5]; // 4 chars + null terminator
       memcpy(powval, tail + 10, 4); // copy "26E2"
       //consoleOut("payload " + String(payload) );
       int decimalValue = (int)strtol(powval, NULL, 16) / 16.59;
       
       cout <<"power value DS3 =0x" << powval << " that is decimal " << decimalValue << "\n<br>" << endl;

    }
    return 0;
}


// ***************************************************************
//           SEND THE QUERY COMMAND
// ***************************************************************
int sendCommand() 
{
    char sendCmd[254] = {0};
    string ecuIdrev= "xxxxxxxxxxxx";
    string invidShort= "XXXX";
    string ecuid = "xxxxxxxxxxxx";
    string invSerial="xxxxxxxxxxxx";
    string invId="xxxx";
    string invIdrev = "xxxx";
    string readdata;
    char str[1];
    sprintf(str, "%d", which);
// command 400w looks like 2401 3A10 1414060001000F13 80971B01B3D6 FBFB061C21DB 2D22 000103FEFE



     // 1st read the inverter serialnr and type and panels connected
     //char str[1];
     //sprintf(str, "%d", which);
     string fileToread="/var/www/ecu_data/inverters/invProperties" + string(str);
     //cout << "fileToread = " << fileToread << "\n<br>" << endl;
     if(fexists(fileToread)) 
     {
        std::ifstream t(fileToread);
        std::stringstream buffer;
     	buffer << t.rdbuf();
     	readdata=buffer.str();
     }
     	else
     {
     	cout << fileToread << " not exists\n<br>" << endl;
     	return 5;
     }
     RSJresource my_inverterRead (readdata);
     //cout << "json from file = " <<  my_inverterRead.as_str() << "\n<br>" <<endl;
     // is like this{"id":"AABBCCDD1122","idinvers":"2211DDCCBBAA",
     invId = my_inverterRead["id"].as<string>();
     //cout << "invId = " << invId << "\n<br>" << endl;
     if(invId == "unpaired") { 
     //cout << "this inverter is not paired, return\n<br>" << endl;
     return 6; }

     //invSerial = my_inverterRead["serial"].as<string>();
     //cout << "invSerial from file = " << invSerial << "\n<br>" << endl;
     invType = my_inverterRead["type"].as<int>();
     cout << "invType = " << invType << "\n<br>" << endl;
     //idx = my_inverterRead["idx"].as<int>();
     //cout << "idx = " << idx << "\n<br>" << endl;
     
     // invId has the form 0xABCD so we skip the 0x
     // since this was saved in reverse order, we reverse it back to use in commands
     invIdrev = invId.substr(4,2) + invId.substr(2,2); // inverter id inversed
     cout << "invIdrev = " << invIdrev << "\n<br>" << endl;
    // sort is id 2 and 1 is BBAA
     
     // this is the id as saved, it was saved in reversed order
     invidShort = invId.substr(2, 4);
     cout << "idShort  = " << invidShort << "\n<br>" << endl;


    // construct the commands, we need more data
    // the serial of the inverter and the id, the ecu id invers
    // we read this from file
     fileToread="/var/www/ecu_data/ecuProperties";
     //cout << "fileToread = " << fileToread << "\n<br>" << endl;
     if(fexists(fileToread))
     {
       std::ifstream t(fileToread);
       std::stringstream buffer;
       buffer << t.rdbuf();
       readdata=buffer.str();
     }
      else
     {
     //cout << fileToread << " not exists\n<br>" << endl;
     return 7;
     }
     RSJresource my_ecuRead (readdata);
     ///id = my_ecuRead["id"].as<string>();
     ecuIdrev = my_ecuRead["idinvers"].as<string>();
     cout << "ecuIdrev from file = " << ecuIdrev << "\n<br>" << endl;



    if(invType == 2) { //ds3
         char queryBaseCommand[][254] = {
          "2401",                      //+ ..string.sub(inv_id[x],3,4)..string.sub(inv_id[x],1,2).. (in>
          //"1414060000050F14", //cahange 14 to 13 and 05 option set to 10         //append (concatenat>
          "1414060001000F13",  // so it looks in the poll cmd datalength 13
          //"FBFB06DC000000000000E2FEFE"
          "FBFB06DE000000000000E4FEFE"
          };    

    } else {       
         char queryBaseCommand[][254] = {
// AF_QUERY_INFO 2401 3A10 1414060000100F13 80971B01B3D6 FBFB06DC000000000000E2FEFE
          "2401",
          "1414060001000F13",  // so it looks in the poll cmd datalength 13
          "FBFB06DE000000000000E4FEFE"
        };
     
      //construct command
     sendCmd[0]='\0'; // make sure its empty
     strncat(sendCmd, queryBaseCommand[0], sizeof(sendCmd) - strlen(sendCmd) - 1); // "2401"
     strncat(sendCmd, invIdrev.c_str(), sizeof(sendCmd) - strlen(sendCmd) - 1);       // inverter ID (reversed)
     //   strncat(sendCmd, invidShort.c_str(), sizeof(sendCmd) - strlen(sendCmd) - 1);       // inverter ID (rev> 
     strncat(sendCmd, queryBaseCommand[1], sizeof(sendCmd) - strlen(sendCmd) - 1); // "14..."
     strncat(sendCmd, ecuIdrev.c_str(), sizeof(sendCmd) - strlen(sendCmd) - 1);    // ECU ID (reversed)
     strncat(sendCmd, queryBaseCommand[2], sizeof(sendCmd) - strlen(sendCmd) - 1); // "FBFB..."
        // the command is ready
  
     if(invType != 2) {
          cout << "the query cmd for yc600 and sq1 = " << sendCmd << "\n<br>" << endl;
     } else {
          cout << "the query cmd for ds3 = " << sendCmd << "\n<br>" << endl;
     }   

   }
   sendZigbee(sendCmd); // sends the command

   if(!waitSerialAvailable()) return 4 ; 
   
   // if there was nothing to read we returned so there is data available
   int result;
   
   cout <<"\n<br<going to read and decode inMessage\n<br>" << endl; 
   
   result = decodeAnswer(); // reads the inmassage and analizes it
   // this can give all kinds of values
      
    cout << "cmd sent\n<br>" << endl;

    //writeFile(result); //which and maxPower
    return result;
} // end sendCommand





// ***********************************************************
//                     M A I N 
// ***********************************************************
// this function is called by setPower.pl
int main ( int argc, char **argv)
{
   cout << "Content-type:text/html\r\n\r\n";
   cout << "<html>\n";
   cout << "<head>\n";
   cout << "<title>RPI ECU PROGRAM</title>\n";
   cout << "</head>\n";
   cout << "<body>\n";
   cout << "<h4>running inverterQuery.cgi</h4>\n";

   // we need an argument to know which inverter to throttle
   //string what;
   //string howMuch;
   if(argc > 1)
   {
       using std::atoi;
       which =atoi(argv[1]);
       //what = string(argv[1]);
       //cout << "there is an argument: which = " << which << "<br>" << endl;
      // maxPower = atoi(argv[2]);
       //howMuch = string(argv[2]);
       //cout << "there is an argument: maxPower = " << maxPower << "<br>" << endl;
    } else {
       cout << "error: no inverternumber supplied \n<br>";
       return(3);
    }
    if( which > 8)
    {
      cout << "error: invalid inverternumber supplied \n<br>";
      return (4);
    }
     cout << "query running with arg "<< which << "\n<br>" << endl;


   // initialize pigpio
    int gpio = ioInit();

// loop
    errorcode = sendCommand();
    cout << "returned by sendCommands() " << errorcode << "\n<br>" << endl;

  
    serClose(fd);
    gpioTerminate();
  // if we are here the polling failed
  // we should make all the values 0 in the invDatafile
  // except for the energy values
  // in which cases we  dont have to make the file 0
  // not if not paired not if no ecu or inverter files 5 6 7
  // determined by the returnstatements in the switch
  if ( errorcode == 5 || errorcode == 6 || errorcode == 7 ) { 
  cout << "query exit with code 1\n<br>" << endl;
  return 1;
}

     cout << "query exit with code 0\n<br>" << endl;
     return 0;
}

