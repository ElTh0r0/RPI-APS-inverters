#!/usr/bin/perl

use strict;
use warnings;

use CGI;
print CGI::header();
print "";
print "<html>";
print "<head>";

print "</head>";
print "<body><span style='font-size:12px; font-family: arial;'>";
print "running chartDateSave.pl";

my $query = new CGI;
my $datum = $query->param('datum');

#we save the date in chartDate.txt
my $filename = '/var/www/ecu_data/chartDate.txt';

my $savecommand = "echo $datum > $filename";
print("savecommand = $savecommand \n<br>");
system($savecommand);

print "\n chartData.txt saved<br>\n<br>";
print "HTTP/1.1 200 OK";

