
#/bin/bash
# this file cleans the journalctl files


#reduce the size
journalctl --rotate
journalctl --vacuum-time=2d
#keep only 2 files
journalctl --vacuum-files=2
timeStamp=$(date +%H-%M-%S)

echo "<br>$timeStamp cleaned journalctl" >> /ramdisk/ecu_log.txt
# to keep the act led out
echo "0" >> /sys/class/leds/ACT/brightness
exit
