
#/bin/bash
# this file cleans the journalctl files


#reduce the size
#journalctl --vacuum-size=2M
#keep only 2 files
#journalctl --vacuum-files=2
timeStamp=$(date +%H-%M-%S)
TZ=$(date +%Z)
echo "<br>$timeStamp"
echo $TZ
exit
