#!/usr/bin/perl
use strict;
use warnings;

use CGI;
print CGI::header();
print "";
print "<html>";
print "<head>";

print "</head>";
print "<body>";

$| = 1;
# we gaan eerst kijken of dit wel nodig is
print"running script expand.pl<br>\n";
my $filenaam = "/var/www/static_data/expand.txt";
open(my $fh, '<', $filenaam) or die "Could not open file '$filenaam' $!";
my $expand = <$fh>;
chomp $expand;

close $fh;

if ( $expand ne "y" ) {

my $rebootcmd = "sudo /sbin/reboot";
my $expandcmd = "sudo /usr/bin/raspi-config --expand-rootfs";
my $filecmd = "echo \"y\" > /var/www/static_data/expand.txt";


print "expanding rootfs...<br>\n";
sleep(5);
print "writing /var/www/static_data/expand.txt...<br>\n";
system($filecmd); #echo y
print "expanding the filesystem ...<br>\n";
system($expandcmd);
print "waiting for user to click reboot ...<br>\n";
#sleep(10);
#system($rebootcmd);

} else {

print "skipped, already expanded";
}
print "HTTP/1.1 200 OK";
