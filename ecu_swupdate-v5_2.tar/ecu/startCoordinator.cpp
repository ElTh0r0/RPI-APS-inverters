#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <errno.h>
//#include <wiringPi.h>
//#include <wiringSerial.h>
#include <iostream>
#include <fstream>
#include <stdbool.h>
#include "RSJparser.tcc"
#include <sstream>
#include <pigpio.h>
#include </usr/lib/cgi-bin/ecu/libraries/serial_IO.h>
using namespace std;

char initCmd[254]={0};
//char s_d[254];
//char * inMessage;
//int readCounter = 0;
//int fd;
//string id_inv;
//string ecu_short;


bool fexists(const std::string& filename) {
  std::ifstream ifile(filename.c_str());
  return (bool)ifile;
}


void sendCommands(bool norMal) {
  string idInvers = "xxxxxxxxxxxx";
  string ecuShort="xxxx";
  string readdata;
  char baseCmd[][254] = {
    "2605030103", // ok   this is a ZB_WRITE_CONFIGURATION CMD //changed to 01
    "410000",     // ok   ZB_SYS_RESET_REQ
    "26050108FFFF", // + ecu_id_reverse,  this is a ZB_WRITE_CONFIGURATION CMD
    "2605870100",  //ok
    "26058302",  // + ecu_id.substring(0,2) + ecu_id.substring(2,4),
    "2605840400000100", //ok
    "240014050F00010100020000150000",  //AF_REGISTER register an application.s en$
    "2600", //ok ZB_START_REQUEST
    // extra command for normal operations
    "2401FFFF1414060001000F1E", // cmd 6 + ecu_reverse
    "FBFB1100000D6030FBD3000000000000000004010281FEFE",
   };


   string fileToread="/var/www/ecu_data/ecuProperties";
   cout << "fileToread = " << fileToread << "\n<br>" << endl;
   if(fexists(fileToread)) {
       std::ifstream t(fileToread);
       std::stringstream buffer;
       buffer << t.rdbuf();
       readdata=buffer.str();
       } else {
       cout << fileToread << " not exists\n<br>" << endl;
       return;
       }
   RSJresource my_ecuRead (readdata);
   // cout << "json from file = " <<  my_ecuRead.as_str() << "\n<br>" <<endl;
   // is like this{"id":"AABBCCDD1122","idinvers":"2211DDCCBBAA","idshort":"BBAA"}
   idInvers = my_ecuRead["idinvers"].as<string>();
   cout << "idinvers from file = " << idInvers << "\n<br>" << endl;
   ecuShort = idInvers.substr(10, 2) + idInvers.substr(8, 2);
   cout << "ecushort  = " << ecuShort << "\n<br>" << endl;
   // alter the base commands
   strncat(baseCmd[2], idInvers.c_str(), 12);
   strncat(baseCmd[4], ecuShort.c_str(), 4);
   strncat(baseCmd[8], idInvers.c_str(), 12);
  
   cout << "base commands edited\n<br>" << endl;
   //cout << "cmd 2 = " << baseCmd[2] << endl;
   //cout << "cmd 4 = " << baseCmd[4] << endl;

   for( int x=0; x < 8; x++ )
   {
      strcpy(initCmd, baseCmd[x]);
     // strcpy(initCmd, strncat(sLen(initCmd), initCmd, sizeof(sLen(initCmd)) + sizeof(initCmd)));
     //strcpy(initCmd, strncat(initCmd, checkSum(initCmd), sizeof(initCmd) + sizeof(checkSum(initCmd))));

     // cout << "cmd  = " << initCmd << "\n<br>" << endl;
      sendZigbee(initCmd);
      waitSerialAvailable();
      inMessage[0]='\0';
      readZigbee();
      
      if(readCounter > 0) 
      { 
          cout << "answer = " << inMessage << "\n<br>" << endl;
      } else { 
         cout << "no answer\n<br>" << endl;
      }
   } // end for loop

   if(norMal == 1) {
      cout << "extra cmd needed\n<br>" << endl;
      // now the normal operations command
      //strncat(baseCmd[8], id_inv.c_str(), 12);
      strncpy(initCmd, baseCmd[8], sizeof(baseCmd[8]));
      //strncat(initCmd, baseCmd[9], sizeof(baseCmd[9]));
      strcat( initCmd, baseCmd[9] );
      //strcpy(initCmd, strncat(sLen(initCmd), initCmd, sizeof(sLen(initCmd)) + sizeof(initCmd)));
      //strcpy(initCmd, strncat(initCmd, checkSum(initCmd), sizeof(initCmd) + sizeof(checkSum(initCmd))));
      cout << "extra cmd = " << initCmd << "\n<br>" << endl;
      sendZigbee(initCmd);
      }
   cout << "all cmds done\n<br>" << endl;
   }


int main (int argc, char **argv)
   {

   cout << "Content-type:text/html\r\n\r\n";
   cout << "<html>\n";
   cout << "<head>\n";
   cout << "<title>RPI ECU PROGAM</title>\n";
   cout << "</head>\n";
   cout << "<body>\n";
   cout << "<h4>running startCoordinator.cgi</h4>\n";

   bool normalOps = false;
   int info;
   int which;
   if(argc > 1)
   {
       using std::atoi;
       which =atoi(argv[1]);
       //cout << "there is an argument: which = " << which << "<br>" << endl;
    } else {
       cout << "error: no argument supplied\n<br>";
       return(3);
    }

    cout << "script startCoordinator running with arg "<< which << "\n<br>" << endl;   
    if(which == 1){normalOps = true;}
 
    int gpio = ioInit();
    if ( gpio > -1 )  gpioSetMode(1, PI_OUTPUT); // pin for the reset

    // We start with a reset command for the zigbee module
    gpioWrite(1, 0);
    gpioDelay(500*1000); 
    gpioWrite(1, 1);
    gpioDelay(1000*1000);

    sendCommands(normalOps);
    cout << "coordinator should be running now\n<br>"<< endl;

    //memset( &initCmd, '\0', sizeof(initCmd) ); //zero out the
    //delayMicroseconds(250);
    serClose(fd);
    gpioTerminate(); 
    return 0;
    //exit(0);
}

