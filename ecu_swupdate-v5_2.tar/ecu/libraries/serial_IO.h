
// this program reads a zigbee message from command line
// adds slen and crc, sends it and reads the answer
// modifications dec 2023 : the buffersize in slen
// removed the delayMicroseconds on several places
// simplified the readZigbee and removed processIncomingByte 

// inspired by https://forums.raspberrypi.com/viewtopic.php?t=349824
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <errno.h>
#include <iostream>
#include <fstream>
#include <sstream>
#include <sys/stat.h>
#include <sys/types.h>
#include <unistd.h>
#include <pigpio.h>
using namespace std;


char inMessage[512];
int readCounter = 0;
int fd;


// ******** convert a char to Hex **************
int StrToHex(char str[])
{
    return (int)strtol(str, 0, 16);
}

// ********* calculate the checksum ****************
char *checkSum(char Command[])
{
    char* buffer_1 = new char[254];
    char buffer_2[254] = {0};

    strncpy(buffer_1, Command, 2); //as starting point use the first two chars
    //gpioDelay(250);  //give memset a little bit of time to empty all the buffers

    for (uint8_t i = 1; i <= (strlen(Command) / 2 - 1); i++)
    {
        strncpy(buffer_2, Command + i * 2, 2);
      //  gpioDelay(250);
        sprintf(buffer_1, "%02X", StrToHex(buffer_1) ^ StrToHex(buffer_2));
      //  gpioDelay(250); //
    }
    return buffer_1;
}

void sendZigbee(char sendString[] )
{
   char bufferSend[254]={0};
   char byteSend[3]={0};
   // put sLen in bufferSend
   sprintf( bufferSend, "%02X", (strlen(sendString) / 2 - 2) ); // slen
   // now add the command and data
   strcat(bufferSend, sendString); // add the command and data
   gpioDelay(250);
   //and add the checkSum
   strcat(bufferSend, checkSum(bufferSend)); // add crc
   gpioDelay(250);
    // now we have the command ready, write it to the port
   
   cout << "\n<br>sendZigbee write FE" << bufferSend << endl;
   // write the FE first
   serWriteByte(fd, 0xFE);
   //
   for (uint8_t i = 0; i <= strlen(bufferSend) / 2 - 1; i++)
        {
         // every iteration we use 2 characters to make a byte
         
            strncpy(byteSend, bufferSend + i * 2, 2);
            //cout << "byteSend : " << byteSend <<endl;

         // turn the two chars to a byte and send this
            serWriteByte(fd, StrToHex(byteSend)); 
            //cout << "StrToHex(byteSend) : " << StrToHex(byteSend) <<endl;
        }
}

// **********   wait for serial available ********************************
bool waitSerialAvailable()
{
  // We start with a loop that lasts 2000 milis
  // we jump out if something is available
  unsigned long wait = gpioTick()/ 1000; //.. convert to millis

  while ( !serDataAvailable(fd ))
      {
      // gpioTick = micros
      if ( gpioTick()/1000 - wait > 2000) 
         { 
            cout << "\nnothing on serial0 after 2000 milisec" <<  endl;
            return false; // return false after 2000 milisec
         } 
      }
  // if we are here there is something available
     gpioDelay(500*1000); // micros to give the sender the time to complete writing
     cout << "\n<br>got data on serial0\n<br> "  <<endl;
     return true;
}


void readZigbee() {
  cout << "\n<br>readZigbee" << endl;
  readCounter = 0;
  char oneChar[10] = {0};
  memset( inMessage, 0, sizeof(inMessage) ); //zero out the
  gpioDelay(250);

  while ( serDataAvailable(fd) > 0 )
    {
      if (readCounter < 256)
      {

     // char oneChar[10] = {0};
        sprintf(oneChar, "%02X", serReadByte(fd));
        strncat(inMessage, oneChar, 2); // append
        readCounter += 1;
       }
       else
       {
         serReadByte(fd); // just read from serial to empty
       }
    }
  cout << "\n<br>inMessage = " << inMessage << endl;
}



int ioInit() {

// initialize pigpio
   if ( gpioInitialise() < 0 ) {
       cout << "gpioInitialize failed" << endl;
       return -1;
   }
// open the port serial0
     char serialPort[] = "/dev/serial0",
     //fd = serOpen("/dev/serial0", 115200, 0);
     fd = serOpen(serialPort, 115200, 0);
     if (fd < 0) {
        printf("Error %i from open: %s\n", errno, strerror(errno));
   // cout << "unable to open serial_port ttyS0\n<br>" << endl;
        return(-2);
     }
   return 0;
}
