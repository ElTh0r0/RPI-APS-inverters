#!/usr/bin/perl
use strict;
use warnings;

use CGI;
print CGI::header();
print "";
print "<html>";
print "<head>";

print "</head>";

print "<body><span style='font-size:12px; font-family: arial;'>";
# the pamater is cmb
print"running script inverterQuery.pl...<br>\n";
$| = 1;

my $query = new CGI;
my $zbt = $query->param('welke');
print "argument is $zbt\n<br> ";

#we call testZigbee.cgi with arg cmd

my $queryCmd="sudo /usr/lib/cgi-bin/ecu/inverterQuery.cgi $zbt";
#my $pollCmd="sudo /usr/lib/cgi-bin/ecu/Poll_test.cgi $zbt";
print "$queryCmd\n<br>";
system($queryCmd);

print "query command processed\n<br>";
print "HTTP:1/1 200 OK";

