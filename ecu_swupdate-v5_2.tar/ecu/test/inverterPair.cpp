
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <errno.h>
//#include <wiringPi.h>
//#include <wiringSerial.h>
#include <iostream>
#include <fstream>
#include <stdbool.h>
#include "/usr/lib/cgi-bin/ecu/libraries/RSJparser.tcc"
#include <sstream>
#include <pigpio.h>
#include </usr/lib/cgi-bin/ecu/libraries/serial_IO.h>

using namespace std;

#include <nlohmann/json.hpp>
using json = nlohmann::json;//using std::strtol;

//char pairCmd[224]={0};
//char s_d[254];
//int  fd;
//char inMessage[254];
//int readCounter = 0;
//string invSerial;
string invSerial = "xxxxxxxxxxxx";
string G_FILEPATH = "/var/www/ecu_data/inverters/invProperties";

// helper to split the incoming char at a certain string
char *split(char *str, const char *delim)
{
    char* p = new char[254]; //strstr(str, delim);
    //char *p = strstr(str, delim);
    p = strstr(str, delim);
    if (p == NULL)  return NULL; // delimiter not found
    *p = '\0';                // terminate string after head
    return p + strlen(delim); // return tail substring
}

// check if the file to open exists
//#include <fstream>
bool fexists(const std::string& filename) {
  std::ifstream ifile(filename.c_str());
  return (bool)ifile;
}

json invdata;
json ecudata;

int readInv() {
      ifstream file(G_FILEPATH);
      if (!file.is_open()) {
          cerr << "Error: cannot find or open " << G_FILEPATH << endl;
          return 1; // Stop het programma met een foutcode
      }
      if (file.peek() == ifstream::traits_type::eof()) {
         cerr << "Fout: Het bestand " << G_FILEPATH << " is fysiek leeg (0 bytes)!" << endl;
         return 1;
      }
      file >> invdata; // now we have an object filedat with all the values
}


 int readEcu() {
 string ECU_FILEPATH="/var/www/ecu_data/ecuProperties";
        ifstream file(ECU_FILEPATH);
        if (!file.is_open()) {
            cerr << "Error: cannot find or open " << ECU_FILEPATH << endl;
            return 1; // Stop het programma met een foutcode
        }
        if (file.peek() == ifstream::traits_type::eof()) {
           cerr << "ERROR: the file" << ECU_FILEPATH << " is empty (0 bytes)!" << endl;
           return 1;
        }
        file >> ecudata; // now we have an object filedat with all the values
  }

// ****************************************************************************
//             D E C O D E   T H E  I N C O M I N G  M E S S A G E
// ****************************************************************************  


bool decodePairMessage(int welke)
{
// we need the fullincomingMessge and the invSns  invSns = inverterSerial
char messageToDecode[256] = {0};
char CC2530_answer_string[9] = "44810000";
char noAnswerFromInverter[32] = "FE0164010064FE034480CD14011F";
char * result;
char temp[13];
char invID[13]={"xxxxxxxxxxxx"}; // testvalue
//char invSerial[13]="xxxxxxxxxxxx"; // testvalue
string readdata;
//received message with inverter id like : 
//for testing
//strncpy(messageToDecode, "FE1C4481000001013A101414003400622305000008FF1A4080001582153A100E08", 66);
//
//  FE1C 4481000001013A101414002700321401000008FFFF4080001582153A100E9D
//  FE0164020067 FE25448100000F0100001414013100204D03000011408000158215A3D610FFFF80971B01A3D63A100DD9FE1C4481000001013A1014140031007D5003000008FFFF4080001582153A100E82
// the 2nd message is shorter 2524020FFFFFFFFFFFFFFFFF14FFFF140F0102000F1100408000157673A3D810FFFF80971B01A3D8D3

    //Serial.println("inMessage = " + String(inMessage));
    //cout << "inMessage = " << inMessage << "\n<br>";
    if (strlen(inMessage) < 255) {
      strncpy(messageToDecode, inMessage, strlen(inMessage));  // get rid of the preceeding FE0164020067
      //gpioDelay(250); // 
    } else {
    cout << "inMessage too long \n<br> " << endl; 
      return false;
    }  
    //Serial.println("messageToDecode = " + String(messageToDecode));
    
    if (strcmp(messageToDecode, noAnswerFromInverter) == 0) // default answer if the asked inverter doesn't send us values we compare the whole message
    //if (strcmp(inMessage, noAnswerFromInverter) == 0)
    { 
    cout << "received noAnswerFromInverter code, returning..\n<br>" << endl;
      return false;
    }
    // a correct pairig answer = 162
    if (strlen(messageToDecode) < 130 || strlen(messageToDecode) > 180)
    //if (strlen(inMessage) < 130 || strlen(inMessage) > 180)
    {
    cout << "no pairing answer, returning...\n<br>" << endl;
      return false;   
    }
// the message is shorter and long enough so continueing    
// look for invSerial !!!!! this is a string !!!!
    if (!strstr(messageToDecode, invSerial.c_str())) {
   //if (!strstr(inMessage, invSerial.c_str())) {
      cout << "not found serialnr, returning" << endl;
      return false;
    }

     // invSerial is in the message so we split there
     cout << "split to find invSerial \n<br>" << endl;
     result=split(messageToDecode, invSerial.c_str());
     //result=split(inMessage, invSerial.c_str());
     cout << "result after 1st split = " << result << "\n<br>"<< endl;
// so long the invSerial is in  the message, we keep splitting it there
     while ( strstr(result, invSerial.c_str()) )
     {
     result=split(result, invSerial.c_str());
     }
     cout << "result after next split = " << result << "\n<br>"<< endl;

// now we know that it is what we expect so do the next test

    strncpy(temp, result, 4); //this must be the invID
    temp[4]='\0';
    //Serial.println("found invID on MessageToDecode" + String(temp));
    memset(invID, 0, sizeof(invID)); //zero out the buffer 
    gpioDelay(250);  

    strncpy(invID, "0x", 2);
    strncat(invID, temp + 2, 2);
    strncat(invID, temp, 2);
    invID[6] = '\0';
    
    if ( string(temp) == "0000" ) {
    cout << "the found id (temp) = " << temp << endl;
    return false;    
    //cout << "not paired but save anyway " << temp << endl;


    }
    cout << "success, got invID: saving: " << invID << "\n<br>" << endl;

   // now we have to save this to the inv properties file 
   // we already know that this file exists
     // 1. new value of 'cal' in the JSON-object
     invdata["id"] = invID;

     ofstream outfile(G_FILEPATH);
     if (outfile.is_open()) {
         outfile << invdata.dump(4); // dump(4) zorgt voor mooie uitlijning (4 spaties)
         // outfile sluit hier automatisch bij de return
     }


  
     //memset( &messageToDecode, 0, sizeof(messageToDecode) ); //zero out the
     //delayMicroseconds(250);     
     memset( &result, 0, sizeof(result) ); //zero out the
     //gpioDelay(250);
     cout << "returning to function sendCommands\n<br>" << endl;
     return(true);
} 

// ******************************************************************
//                              SEND THE COMMANDS
// ******************************************************************
int sendCommands(int welke)
{
  string idInvers = "xxxxxxxxxxxx";
  string ecuShort="xxxx";
  string invSerial = "xxxxxxxxxxxx";

  string readdata;
  int success = 0;
  //bool success = false;
  char sendCmd[254];
  char baseCmd[][254] = {
    "24020FFFFFFFFFFFFFFFFF14FFFF140D0200000F1100", // + String(inv_sn) + "FFFF10FFFF" + ecu_id_reverse,
    "24020FFFFFFFFFFFFFFFFF14FFFF140C0201000F0600",  // + String(inv_sn),
    "24020FFFFFFFFFFFFFFFFF14FFFF140F0102000F1100",  // + String(inv_sn) + ecu_id.substring(2,4) + ecu_id.substring(0,2) + "10FFFF" + ecu_id_reverse,
    "24020FFFFFFFFFFFFFFFFF14FFFF14010103000F0600",  // + ecu_id_reverse
   };
   // we need to read inverter serial, ecu id short and ecu_id invers
   //read the ecu invers
   
   // we have the dat in json object ecudata 
   cout << "ecudata from file = " <<  ecudata << "\n<br>" <<endl;
   // is like this{"id":"AABBCCDD1122","idinvers":"2211DDCCBBAA","idshort":"BBAA"}
   idInvers = ecudata.value("idinvers","-1");
   cout << "idinvers from file = " << idInvers << "\n<br>" << endl;
   ecuShort = idInvers.substr(8, 4);
   cout << "ecushort  = " << ecuShort << "\n<br>" << endl;

   // now read the inverter serialnr from inveProperties    
   
   cout << "invdata from file = " <<  invdata << "\n<br>" <<endl;
   //invSerial= invdata.value("serial","n/a");
   invSerial = nlohmann::to_string(invdata["serial"]);
   cout << "serial from file = " << invSerial << "\n<br>" << endl;

   cout << "trying to pair inverter"<< welke << "\n<br>" << endl;
   // now we have all the data and we can contruct the commands
   // ***************************** command 1 ********************************************
   // now build command 0 this is prefix + "0D0200000F1100" + String(invSerial) + "FFFF10FFFF" + ecu_id_reverse,
   strncpy(sendCmd, baseCmd[0], sizeof(baseCmd[0]));
   strncat(sendCmd, invSerial.c_str(), 13);
   strncat(sendCmd, "FFFF10FFFF", 11);
   strncat(sendCmd, idInvers.c_str(), 13 );
   //strncat(baseCmd[0], invSerial.c_str(), 13);
   //strncat(baseCmd[0], "FFFF10FFFF", 11 );
   //strncat(baseCmd[0], idInvers.c_str(), 13);
   //sprintf(bufferSend, "%02X", (strlen(sendCmd) / 2 - 2)); //slen 
   //strcat(sendCmd, strncat(sLen(sendCmd), sendCmd, sizeof(sLen(sendCmd)) + sizeof(sendCmd)));
   //strncat(sendCmd, checkSum(sendCmd), sizeof(checkSum(sendCmd))));
   cout << "send cmd 0 " << sendCmd << "\n<br>" << endl; //oke
   sendZigbee(sendCmd);
   waitSerialAvailable();
   //inMessage = readZigbee(s_d);
   readZigbee();
   if(readCounter == 0 || strlen(inMessage) < 4) { return(4); }
   //cout << "inMessage = " << inMessage << "\n<br>";
   // we are not interested in the answer at this time, however when no answer we return
   // build and send command 1
   // cmd_prefix + "0C0201000F0600" + String(inv_sn),
   strncpy(sendCmd, baseCmd[1], sizeof(baseCmd[1]));
   strncat(sendCmd, invSerial.c_str(), 13);
   // add len and crc
   //strcpy(sendCmd, strncat(sLen(sendCmd), sendCmd, sizeof(sLen(sendCmd)) + sizeof(sendCmd)));
   //strcpy(sendCmd, strncat(sendCmd, checkSum(sendCmd), sizeof(sendCmd) + sizeof(checkSum(sendCmd))));
   cout << "send cmd 1 " << sendCmd << "\n<br>" << endl; //oke
   sendZigbee(sendCmd);
   waitSerialAvailable();
   //inMessage = NULL;
   inMessage[0]='\0';
//   cout << "inMessage before read " << inMessage << endl;
//   cout << "s_d before read" << s_d << endl;
   readZigbee();   
   if(readCounter == 0 || strlen(inMessage) < 4) { return(4); }
   //cout << "inMessage = " << inMessage << "\n<br>";
   // it seems that we here already can have a good answer
   // if this is true we dont have to nalize the other answers
   //if(decodePairMessage(welke) == true) { success = 1;}
   if(decodePairMessage(welke)){ success = true;}

   cout << "proceeding with the next cmd \n<br> " << endl;
   // build and send command 2
   // cmd_prefix + + invSerial + short ecu_id_reverse, + 10FFF + ecu_id_reverse
   strncpy(sendCmd, baseCmd[2], sizeof(baseCmd[2]));
   strncat(sendCmd, invSerial.c_str(), 13);
   strncat(sendCmd, ecuShort.c_str(), 5);
   strncat(sendCmd, "10FFFF", 7);
   strncat(sendCmd, idInvers.c_str(), 13);
   //strcpy(sendCmd, strncat(sLen(sendCmd), sendCmd, sizeof(sLen(sendCmd)) + sizeof(sendCmd)));
   //strcpy(sendCmd, strncat(sendCmd, checkSum(sendCmd), sizeof(sendCmd) + sizeof(checkSum(sendCmd))));
   cout << "send cmd 2 " << sendCmd << "\n<br>" << endl; // oke
   sendZigbee(sendCmd);
   waitSerialAvailable(); 
   inMessage[0]='\0';
   readZigbee(); // the answer is in inMessage
   if(readCounter == 0 || strlen(inMessage) < 4) { return(4); }
   cout << "decode inMessage = " << inMessage << "\n<br>";
   // now we should check if we have an answer
   // we decode if success = stil false
   if(!success){
     if(decodePairMessage(welke) == true) {success = 1;}
   }
   // build and send command 3
   //pcmd_prefix + "010103000F0600" + ecu_id_reverse
   
  // decodePairMessage(welke);
   cout << "proceeding with the next cmd \n<br> " << endl;

   strncpy(sendCmd, baseCmd[3], sizeof(baseCmd[3]));
   strncat(sendCmd, idInvers.c_str(), 13);
   //strcpy(sendCmd, strncat(sLen(sendCmd), sendCmd, sizeof(sLen(sendCmd)) + sizeof(sendCmd)));
   //strcpy(sendCmd, strncat(sendCmd, checkSum(sendCmd), sizeof(sendCmd) + sizeof(checkSum(sendCmd))));
   cout << "send cmd 3 " << sendCmd << "<br> " << endl;
   sendZigbee(sendCmd);
   waitSerialAvailable();
   inMessage[0]='\0';
   readZigbee(); // the answer is in inMessage
   cout << "decode inMessage = " << inMessage << "\n<br>";
   // now we should check if we have an answer
   // we only decode if success = false
   if(!success) {
   if(decodePairMessage(welke) == true) { success = 1; };
   }//now check if we have an answer
   cout << "all pair cmds done<br>" << endl;
   if(!success) { return(5);}

   return 0;
}

int charToInt(char c)
{
   int arr[]={0,1,2,3,4,5,6,7,8,9};
   return arr[c-'0'];
}


// ***********************************************************
//                                MAIN
// ***********************************************************
int main (int argc, char **argv)
{

   cout << "Content-type:text/html\r\n\r\n";
   cout << "<html>\n";
   cout << "<head>\n";
   cout << "<title>RPI ECU PROGAM</title>\n";
   cout << "</head>\n";
   cout << "<body>\n";
   cout << "<h4>running inverterPair.cgi</h4>\n";

   int info;
   int which;
   if(argc > 1)
   {
       using std::atoi;
       which =atoi(argv[1]);     
       //cout << "there is an argument: which = " << which << "<br>" << endl;
    } else {
       cout << "error: no inverternumber supplied\n<br>";
       return(3);
    }

    cout << "script inverterpair running with arg"<< which << "<br>" << endl;

    G_FILEPATH += to_string(which);
    
    readInv(); 
    readEcu();
    // now we have obects ecudata and invdata with our vars

    // cout << "\n";
    // printf("this is printf<br>");
    // cout << "which = "<< which << endl;

    // initialize pigpio
    int gpio = ioInit();
   // run the commands
    info = sendCommands(which);

   cout << "info = " << info << "\n<br>" << endl;
   switch(info) {
     case 0:
       cout << "successfully paired \n<br>";
       break;
     case 1:
       cout << "could not read /var/www/ecu_data/ecuProperties<br>";
       break;
     case 2:
       cout << "could not read /var/www/ecu_data/inverters/invProperties#<br>";
       break;
     case 3:
       cout << "no valid argument (inverternr) supplied\n<br>";
     case 4:
       cout << "no incoming messages\n<br>";
     case 5:
       cout << "pairing failed, try again...\n<br>";
     default:
       cout << "inverterPair ready\n<br>";
   }
     serClose(fd);
     gpioTerminate();
     return info;
}
