#!/bin/bash

#this script writes credentials in /etc/NetworkManager/system-connections/general.nmconnection

ssid=$1
pswd=$2

echo "script nmcredentials_save.pl args: "
echo $ssid
echo $pswd
echo "<br>\n"
# we have to write the credentials into general.nmconnection
# doing his with sed doesn't work
# maybe we should do this with nmcli works!
nmcli con modify general ssid $ssid
nmcli con modify general wifi-sec.psk $pswd

echo "<br><saved wifi configuration<br>\n"

