#!/usr/bin/perl
use strict;
use warnings;
#use getopt::long;
use CGI;
print CGI::header();
print "";
print "<html>";
print "<head>";

print "</head>";
print "<body><span style='font-size:12px; font-family: arial;'>";


$| = 1;
# this script is used to setup a static ip


my $query = new CGI;
# check if all arguments supplied
die "Missing router ip, abort" unless $query->param('gw');
die "Missing static ip, abort" unless $query->param('ip');
die "Missing dns ip, abort" unless $query->param('nm');

# we deceased when not enoug arguments supplied
my $gw = $query->param('gw');
my $ip = $query->param('ip');
my $dns = $query->param('nm');
#

print"<br>static ip configuration<br>\n";
print "gw = $gw, ip = $ip, dns = $dns <br>\n";
#print "ip  = $ip<br>\n";
#print "dns  = $dns<br>\n";

# the connection to modify = general
#nmcli con mod "general" ipv4.addresses 10.0.0.220/24 ipv4.method manual
#nmcli con mod "general" ipv4.gateway 10.0.0.1
#nmcli con mod "general" ipv4.dns 10.0.0.1

my $cmd1 = "nmcli con modify \"general\" ipv4.addresses $ip/24 ipv4.method manual";
print "command1 = $cmd1<br>\n";
my $cmd2 = "nmcli con modify \"general\" ipv4.gateway $gw";
print "command2 = $cmd2<br>\n";
my $cmd3 = "nmcli con modify \"general\" ipv4.dns $gw";
print "command3 = $cmd3<br>\n";

system($cmd1);
system($cmd2);
system($cmd3);

my $statuscommand = "echo static > /var/www/ecu_data/wifistatus.txt";
system($statuscommand);

print "<br>static ip configured, ip should now be $ip<br>\n";
print "please click the button to restart the network<br>\n";
print "HTTP/1.1 200 OK"; 
