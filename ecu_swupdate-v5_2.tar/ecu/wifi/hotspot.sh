#!/bin/bash

nmcli con delete TEST_AP
#nmcli con add type wifi ifname wlan0 mode ap con-name HOTSPOT ssid RPI-ECU4 autoconnect false
#nmcli con modify HOTSPOT wifi.band bg
#nmcli con modify HOTSPOT wifi.channel 3
#nmcli con modify HOTSPOT wifi.cloned-mac-address 00:12:34:56:78:9a
#nmcli con modify HOTSPOT  wifi-sec.key-mgmt wpa-psk
#nmcli con modify HOTSPOT wifi-sec.proto rsn
#nmcli con modify HOTSPOT  wifi-sec.group ccmp
#nmcli con modify HOTSPOT wifi-sec.pairwise ccmp
#nmcli con modify HOTSPOT wifi-sec.psk "rpiecu123"
#nmcli con modify HOTSPOT ipv4.method shared ipv4.address 192.168.4.1/24
#nmcli con modify HOTSPOT ipv6.method disabled
nmcli con up HOTSPOT 
echo "ap RPI-ECU = up, connect with passwd 12345678"
/bin/sleep 10
echo "putting the AP down"
nmcli con down HOTSPOT

echo "ap RPI-ECU timed out, going to reboot goodbye"
#perl /usr/lib/cgi-bin/ecu/system/reboot.pl
exit 0
