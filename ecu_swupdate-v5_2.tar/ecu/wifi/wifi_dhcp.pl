#!/usr/bin/perl
use strict;
use warnings;

use CGI;
print CGI::header();
print "";
print "<html>";
print "<head>";

print "</head>";
print "<body><span style='font-size:12px; font-family: arial;'>";

print"<br>script wifi_dhcp.pl running <br>\n";
$| = 1;
# this script is used for setup of a dhcp ip
#my $empty = "";
my $cmd1 = 'nmcli con modify general ipv4.gateway ""';

my $cmd2 = 'nmcli con modify general ipv4.addresses "" ipv4.method auto';
#my $cmd2 = 'nmcli con modify general ipv4.gateway ""';
my $cmd3 = 'nmcli con modify general ipv4.dns ""';
 
#my $cmd1 = 'nmcli c mod general ipv4.address ""';
#my $cmd2 = "nmcli c mod general ipv4.method auto";
#my $cmd3 = 'nmcli c mod general ipv4.dns ""';
print "command1 = $cmd1 <br>\n";
print "command2 = $cmd2 <br>\n";
print "command3 = $cmd3 <br>\n";

system($cmd1);
system($cmd2);
system($cmd3);

my $statuscommand = "echo dhcp > /var/www/ecu_data/wifistatus.txt";
system($statuscommand);
print "modified connection general to dhcp<br>\n";
print "click the button to effectuate<br>\n";

print "HTTP/1.1 200 OK"; 




