#!/usr/bin/perl
use strict;
use warnings;
#use getopt::long;
use CGI;
print CGI::header();
print "";
print "<html>";
print "<head>";

print "</head>";
print "<body><span style='font-size:12px; font-family: arial;'>";

$| = 1;
# this script is used to restart the wificonnection
print "running script wifi_restart.pl<br>\n";
my $restartcmd = "nmcli c down general & nmcli c up general";
print "going to re-activate the connection<br>\n";
print "If you configured a new ip, this page will not be resposive anymore<br\n";
system ($restartcmd);

print "HTTP/1.1 200 OK";
