#!/usr/bin/env bash

#this script is started by the service wificheck.service
# /etc/systemd/system/wificheck.service

# we know that all attepmts to wificonnect are passed.

/bin/sleep 60 # wait a little untill connection attempts are done

echo $(date) > /home/wificheck/check.txt # this file only contains the data now
#/bin/sleep 30 # wait a little untill connection is done
var="iwgetid -r" # gives us the ssid

eval "$var"
y=$(eval "$var")
echo "y = $y"

if [ ! -z "$y" ]; then
    _IP=$(hostname -I) || true
    printf 'Skipping WiFi Connect\n'
    echo "check_wificonnect says: connected to $y" >> /home/wificheck/check.txt

    #write the ip to ecu_data/myipnr.txt
    echo "$_IP">/var/www/ecu_data/myipnr.txt
    echo "0" >> /sys/class/leds/ACT/brightness # led off

    #   /bin/sleep 60 # we slept enough

    # if there was no ip we are not connected, We start AP now
else
    echo "Starting WiFi Connect\n"

    nmcli con delete TEST-AP
#    nmcli con add type wifi ifname wlan0 mode ap con-name TEST-AP ssid RPI-ECU autoconnect false
#    nmcli con modify TEST-AP wifi.band bg
#    nmcli con modify TEST-AP wifi.channel 3
#    nmcli con modify TEST-AP wifi.cloned-mac-address 00:12:34:56:78:9a
#    nmcli con modify TEST-AP wifi-sec.key-mgmt wpa-psk
 #    nmcli con modify TEST-AP wifi-sec.proto rsn
 #    nmcli con modify TEST-AP wifi-sec.group ccmp
 #    nmcli con modify TEST-AP wifi-sec.pairwise ccmp
#    nmcli con modify TEST-AP wifi-sec.psk "rpiecu123"
#    nmcli con modify TEST-AP ipv4.method shared ipv4.address 192.168.4.1/24
#    nmcli con modify TEST-AP ipv6.method disabled
    nmcli con up HOTSPOT

    echo $(date) > /home/wificheck/check.txt
    echo "no wifi connection could be made, AP started" >> check.txt

  # we keep this ap up for 5 minutes, after that we reboot
  # This means a retry to connect

  /bin/sleep 300

  # now we have to check if there was a static ip set and set this again
#  file="/var/www/ecu_data/wifistatus.txt"
#  status=$(cat "$file")
#  echo $status
#  if [ $status = "static" ]
#  then
#   cp /etc/network/interfaces_stat /etc/network/interfaces
#   echo "wifistatus revised"
#fi

   perl /usr/lib/cgi-bin/ecu/system/reboot.pl
fi
echo "done"
exit 0
