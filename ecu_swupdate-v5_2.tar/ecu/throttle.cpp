// this program works as follows
// the arguments are collected and put in which and throtVal
// then we call sendCommand
// sendCommand returns all kinds of errors, only when 0 it is success
//


#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <errno.h>
#include <iostream>
#include <fstream>
#include <stdbool.h>
#include "RSJparser.tcc"
#include <math.h>
#include <sstream>
#include <iomanip>
#include <pigpio.h>
#include <cmath>
//#include <nlohmann/json.hpp>  // You need this library
// iclude our own library for the io operations
#include </usr/lib/cgi-bin/ecu/libraries/serial_IO.h>
//using json = nlohmann::json;
using namespace std;

#define factorYC600  29

int invType;
int panels[4] ={0,0,0,0};
int which;
int maxPower;
int idx;
int errorcode;
float totalpw; // global as we need to log this
int timespan;
float sigQ;
int invCal;
float calibratedVal;
float calibrateFactor;
int programmedVal;


char *split(char *str, const char *delim)
{
    char* p = new char[254]; //strstr(str, delim);
    //char *p = strstr(str, delim);
    p = strstr(str, delim);
   if (p == NULL)
        return NULL; // delimiter not found
    *p = '\0';                // terminate string after head
    return p + strlen(delim); // return tail substring
}
//#include <fstream>
bool fexists(const std::string& filename) {
  std::ifstream ifile(filename.c_str());
  return (bool)ifile;
}

void writeFile(int res) {
    string fileToWrite = "/var/www/ecu_data/inverters/throtvals.json";
    string writedata;

    // Load JSON file if exists
    if (fexists(fileToWrite)) {
        ifstream t(fileToWrite);
        stringstream buffer;
        buffer << t.rdbuf();
        writedata = buffer.str();
        t.close();
    } else {
        writedata = "{}"; // start with empty object
        cout << fileToWrite << " not exists, creating new file\n";
    }

    // Determine new throttle value
    string newThrotval = (res != 0 && res != 16) ? "-1" : to_string(maxPower);

    // Build key
    string keyToUpdate = "inv" + to_string(which);

    // Look for existing key
    size_t keyPos = writedata.find("\"" + keyToUpdate + "\"");
    if (keyPos != string::npos) {
        // Key exists → replace its value
        size_t colonPos = writedata.find(':', keyPos);
        if (colonPos != string::npos) {
            size_t valueStart = writedata.find_first_not_of(" \t\n", colonPos + 1);
            size_t valueEnd = writedata.find_first_of(",}", valueStart);
            if (valueStart != string::npos && valueEnd != string::npos) {
                writedata.replace(valueStart, valueEnd - valueStart, "\"" + newThrotval + "\"");
            }
        }
    } else {
        // Key not found → append it before the last }
        size_t insertPos = writedata.rfind('}');
        if (insertPos != string::npos) {
            if (insertPos > 1 && writedata[insertPos - 1] != '{') {
                writedata.insert(insertPos, ", \"" + keyToUpdate + "\": \"" + newThrotval + "\"");
            } else {
                writedata.insert(insertPos, " \"" + keyToUpdate + "\": \"" + newThrotval + "\"");
            }
        }
    }

    // Save back
    ofstream out(fileToWrite);
    out << writedata;
    out.close();

    cout << "Updated " << fileToWrite << " with " << keyToUpdate << ":" << newThrotval << "\n";
}
// *********************************************************
//             D E C O D E     A N S W E R
// *********************************************************
int decodeAnswer() 
{                      
    char messageToDecode[512] = {0};
    char s_d[512] = {0};
    char *tail;
    uint8_t Message_begin_offset = 0;
    int fault = 0;
    readZigbee(); // puts the result in inMessage
    strcpy(messageToDecode, inMessage);
//    cout << "\n<br>messageToDecode = " << messageToDecode << "\n<br>"<< endl;
//    cout << "\n<br>length of messageToDecode = " << strlen(messageToDecode) << "\n<br>" << endl;
    if(!messageToDecode) return 50;

// when we get this FE0164010064 FE034480001400D3
// or               FE0164010064 FE0345C43A1000A8 FE034480001400D3

    //if(strstr(messageToDecode,  "FE01640100") == NULL) // answer to AF_DATA_REQUEST 00=success
    //{
    // cout << "AF_DATA_REQUEST failed\n<br>" << endl;
    // fault = 10;    
   // } else
   // if (strstr(messageToDecode, "FE03448000") == NULL) //  AF_DATA_CONFIRM the 00 byte = success
   // {
   //   cout << "no AF_DATA_CONFIRM\n<br>" << endl;
   //   fault = 11;
   // } else
   // if (strstr(messageToDecode, "FE0345C4") == NULL) //  ZDO_SRC_RTG_IND
    //{
     // cout << "no route receipt\n<br>" << endl;
     // fault=12; // this command seems facultative
    //} else 
    // if both 4481 (AF_INCOMING_MESSAGE) and 4480 (AD_DATA_CONFIRM)  n0t exist the command fails
    if (strstr(messageToDecode, "4481") == NULL)
    {
      cout << "no  AF_INCOMING_MSG and no AF_DATA_CONFIRM\n<br>" << endl;
      fault=13;
    }

    if(fault > 9 ) { 
      return fault;
    }

    tail = split(messageToDecode, "FBFB"); // remove the 0000 as well
    cout << "message split after FBFB (payload) " << tail << "\n<br>" << endl;

// **************************************************************************
//                         YC600
// **************************************************************************
    if(invType != 2) {
    // we know the tail is

    //BFB4DDE041105440FE5020F32B003CF05440FE5020F32B0066604CC0EA3A804D70214050C100FD80ED07A0F32B0056A054F01900>
    //FE480068ACE8ACE000130103030190604001D1B15 3B66 00000000FEFE3A100E5D
    char target[5] ={"3B66"}; // the value is richt before this

    char *ptr = strstr(tail, target); // find "3B66"
    if (ptr != NULL && ptr - tail >= 4) {
        char before[5];
        strncpy(before, ptr - 4, 4);
        before[4] = '\0';
        //int decimalValue = (strtol(before, NULL, 16) / factorYC600; //was 28.89  convert from hex string to int
        int decimalValue = (strtol(before, NULL, 16) * 100 + 2889/2) / 2889;
        //double result = decimalValue / 28.89;
        cout << "power value YC600 = 0x" << before << " that is decimal " << decimalValue << "\n<br>" << endl;
        //we must compare decimalValue with maxPower
        // so we have calculate it back with the calibrateFactoe

        programmedVal = decimalValue - invCal;
        cout << "the throttlevalue from inverter = " << programmedVal << "<br>\n"<< endl;
        if(fabs(maxPower - programmedVal) > 2)   return 16;
        //if(fabs(decimalValue - (maxPower)) > 2)   return 16; 
        cout << "programmedVal and maxPower are equal \n<br>" << endl;

     } 
 // **************************************************************************
 //                         DS3
 // **************************************************************************

   } else {
    // invType == 2
     char powval[5]; // 4 chars + null terminator
       memcpy(powval, tail + 10, 4); // copy "26E2"
       //consoleOut("payload " + String(payload) );
       //int decimalValue = (int)strtol(powval, NULL, 16) / 16.59;
       int decimalValue = (strtol(powval, NULL, 16) * 100 + 1659/2) / 1659;
       cout <<"power value DS3 = 0x" << powval << " that is decimal " << decimalValue << "\n<br>" << endl;
       //cout << "the throttlevalue from inverter = " << decimalValue << "<br>\n"<< endl;
       //checkVal = ceil(maxPower * ( 1.0 + invCal / 100.0)) ;       
       //we must compare decimalValue with maxPower
       // so we have calculate it back with the calibrateFactoe
       programmedVal = decimalValue - invCal ;
       cout << "the throttlevalue from inverter = " << programmedVal << "<br>\n"<< endl;
       //cout <<"checkVal = " << checkVal << "\n<br>" << endl;
        //if(fabs(decimalValue - (maxPower)) > 2)  return 16;
       
       if(fabs(maxPower - programmedVal) > 2)   return 16;
       cout << "programmedVal and maxPower are equal \n<br>" << endl;
    }
    // if we are here we have a message like
    //FE0164010064FE034480001400D3FE0345C4A2F600D6
    //FE27448100000601A2F61414005C00617054000013704000202594FBFB06DE02000000000000FEFEA2F60E9A
    //tail 0601A2F61414005C00617054000013704000202594 FBFB 06 DE0200000000 0000FEFEA2F60E9A
    // the data starts after FBFB  len=6 data = DE0200000000  checksum 0000 end-tag FEFE
    return 0;
}




// ***************************************************************
//           SEND THE THROTLLE COMMAND
// ***************************************************************
int sendCommand() 
{
    char sendCmd[254] = {0};
    string ecuIdrev= "xxxxxxxxxxxx";
    string invidShort= "XXXX";
    string ecuid = "xxxxxxxxxxxx";
    string invSerial="xxxxxxxxxxxx";
    string invId="xxxx";
    string invIdrev = "xxxx";
    string readdata;

    char str[1];
    sprintf(str, "%d", which);
// command 400w looks like 2401 3A10 1414060001000F13 80971B01B3D6 FBFB061C21DB 2D22 000103FEFE



     // 1st read the inverter serialnr and type and panels connected
     //char str[1];
     //sprintf(str, "%d", which);
     string fileToread="/var/www/ecu_data/inverters/invProperties" + string(str);
     //cout << "fileToread = " << fileToread << "\n<br>" << endl;
     if(fexists(fileToread)) 
     {
        std::ifstream t(fileToread);
        std::stringstream buffer;
     	buffer << t.rdbuf();
     	readdata=buffer.str();
     }
     	else
     {
     	cout << fileToread << " not exists\n<br>" << endl;
     	return 5;
     }
     RSJresource my_inverterRead (readdata);
     //cout << "json from file = " <<  my_inverterRead.as_str() << "\n<br>" <<endl;
     // is like this{"id":"AABBCCDD1122","idinvers":"2211DDCCBBAA",
     invId = my_inverterRead["id"].as<string>();
     //cout << "invId = " << invId << "\n<br>" << endl;
     if(invId == "unpaired") { 
     //cout << "this inverter is not paired, return\n<br>" << endl;
     return 6; }

     //invSerial = my_inverterRead["serial"].as<string>();
     //cout << "invSerial from file = " << invSerial << "\n<br>" << endl;
     invType = my_inverterRead["type"].as<int>();
     cout << "invType = " << invType << "\n<br>" << endl;
     //idx = my_inverterRead["idx"].as<int>();
     //cout << "idx = " << idx << "\n<br>" << endl;
     
     // invId has the form 0xABCD so we skip the 0x
     // since this was saved in reverse order, we reverse it back to use in commands
     invIdrev = invId.substr(4,2) + invId.substr(2,2); // inverter id inversed
     cout << "invIdrev = " << invIdrev << "\n<br>" << endl;
    // sort is id 2 and 1 is BBAA
     
     // this is the id as saved, it was saved in reversed order
     invidShort = invId.substr(2, 4);
     cout << "idShort  = " << invidShort << "\n<br>" << endl;

     invCal = my_inverterRead["cal"].as<int>(); 
     //cout << "invCal = " << invCal << "\n<br>" << endl;
     //calibrateFactor = 1.0 + invCal / 100.0;
     //cout << "calibrateFactor = " << calibrateFactor << "\n<br>" << endl;
     calibratedVal = maxPower + invCal;
     cout << "the calibrated user input = " << calibratedVal << "\n<br>" << endl;
    // construct the commands, we need more data
    // the serial of the inverter and the id, the ecu id invers
    // we read this from file
     fileToread="/var/www/ecu_data/ecuProperties";
     //cout << "fileToread = " << fileToread << "\n<br>" << endl;
     if(fexists(fileToread))
     {
       std::ifstream t(fileToread);
       std::stringstream buffer;
       buffer << t.rdbuf();
       readdata=buffer.str();
     }
      else
     {
     //cout << fileToread << " not exists\n<br>" << endl;
     return 7;
     }
     RSJresource my_ecuRead (readdata);
     ///id = my_ecuRead["id"].as<string>();
     ecuIdrev = my_ecuRead["idinvers"].as<string>();
     cout << "ecuIdrev from file = " << ecuIdrev << "\n<br>" << endl;

     //calibratedValue== static_cast<int>(ceil(maxPower * (1.0 + invCal / 100.0));


    if(invType == 2) { //ds3
      // transform maxPower to hex and calculate validation value vv
      // * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * *
      // *                       D S 3                                         *
      // * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * *

     int Scaled = (calibratedVal * 1659 + 50) / 100; // this rounds up instead of down
     uint8_t msb = (Scaled >> 8) & 0xFF; // 0x02
     uint8_t lsb = Scaled & 0xFF;        // 0x58
     // Compute validation byte
     uint8_t s = (msb + lsb) & 0xFF;
     uint8_t vv = (s - 0x29) & 0xFF;
     //convert the uint_8 to char
     char msbStr[3]; snprintf(msbStr, sizeof(msbStr), "%02X", msb);
     char lsbStr[3]; snprintf(lsbStr, sizeof(lsbStr), "%02X", lsb);
     char vvStr[3];  snprintf(vvStr,  sizeof(vvStr),  "%02X", vv);
  
     sendCmd[0]='\0'; // make sure its empty
    //construct the throttle command
    snprintf(sendCmd, sizeof(sendCmd),
    "2401%s1414060001000F13%sFBFB06AA270000%s%s01%sFEFE",        
    invIdrev.c_str(),ecuIdrev.c_str(), msbStr, lsbStr, vvStr);

     cout << "the throttle cmd for ds3 = " << sendCmd << "\n<br>" << endl;    

    } else {       

     // * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * *
     // *                       Y C 6 0 0                                     * 
     // * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * *
     //int Scaled = ceil(calibratedValue * factorYC600);  // was 28.89
     int Scaled = (calibratedVal * 2889 + 50) / 100; // this rounds up instead of down

     char hexStr[5]; // Enough for "FFFFFFFF" + null terminator
     // Convert Scaled to hexadecimal string
     // %04X ensures it's always 4 hex digits, uppercase, zero-padded
     cout << "Scaled = " << Scaled << "\n<br>"<< endl;
     snprintf(hexStr, sizeof(hexStr), "%04X", Scaled);
     cout << "hexStr = " << hexStr << "\n<br>"<< endl;
     //construct the throttle command
     sendCmd[0]='\0'; // make sure its empty

     int getal=0;
     char bytes2summerize[15]={"061C8C02"};
     // add the trottle value
     strncat(bytes2summerize, hexStr, sizeof(bytes2summerize) - strlen(bytes2summerize) - 1);
     strncat(bytes2summerize, "00", sizeof(bytes2summerize) - strlen(bytes2summerize) - 1);     
    //
     cout << "the last 7 bytes are " << bytes2summerize << "\n<br>"<< endl;
     for(int x=0; x<strlen(bytes2summerize); x += 2) {
        // Convert two hex chars into a byte
        char hexByte[3] = { bytes2summerize[x], bytes2summerize[x + 1], '\0' }; 
        int value = strtol(hexByte, NULL, 16); // convert hex string to int
        getal += value;
       }
    char hexString[10];  // Enough space for hex + null terminator
    // Convert int to hex and store in hexString
    snprintf(hexString, sizeof(hexString), "%04X", getal);                  
    snprintf(sendCmd, sizeof(sendCmd),
    "2401%s1414060001000F13%sFBFB061C8C02%s00%sFEFE",
    invIdrev.c_str(),ecuIdrev.c_str(), hexStr, hexString );

      // the command is ready
    cout << "the throttle cmd for yc600 and sq1 = " << sendCmd << "<br>\n" << endl;
   }

   // now sendCmd contains the throttle command which is specific for the invertertype.
   // we send it now
   sendZigbee(sendCmd);
   // send the throttle command and discard the response
   if(!waitSerialAvailable()) return 4 ;
   readZigbee(); //we now have an inmessage, we flush that
   inMessage[0]='\0'; //empty the incoming message
   sendCmd[0]='\0'; 
   // now we send a dummy which is equal to both types
   snprintf(sendCmd, sizeof(sendCmd), "2401%s1414060001000F13%sFBFB06DE00000000000000FEFE", invIdrev.c_str(), ecuIdrev.c_str());
   cout << "\n<br>the generic dummy command" << sendCmd << "\n<br>" << endl;
   sendZigbee(sendCmd);
   // send the dummy command and discard the response
   if(!waitSerialAvailable()) return 4 ;
   readZigbee(); //we now have an inmessage, we flush that
   inMessage[0]='\0'; //empty the incoming message
   sendCmd[0]='\0';
   // now we are going to send the query command, also equal for both types
   snprintf(sendCmd, sizeof(sendCmd), "2401%s1414060001000F13%sFBFB06DE000000000000E4FEFE", invIdrev.c_str(), ecuIdrev.c_str());
   cout << "\n<br>the generic query command" << sendCmd << "\n<br>" << endl;
   // this command we are going send and analyze
   sendZigbee(sendCmd);  

   if(!waitSerialAvailable()) return 4 ; 
   
   // if there was nothing to read we returned so there is data available
   int result;
   
   cout <<"\n<br<going to read and decode inMessage\n<br>" << endl; 
   
   result = decodeAnswer(); // reads the inmassage and analizes it
   // this can give all kinds of values
   // when 0 it is oke  and when 16 mismatch
      
    cout << "cmd sent\n<br>" << endl;

    writeFile(result);  //which and maxPower are global
    return result;
} // end sendCommand

string thisTime() {
    time_t noow = time(nullptr);
    tm * ptm = localtime(&noow);
    char buffer[32];
    //strftime(buffer, 32, "%a, %d.%m.%Y %H:%M:%S", ptm);
    strftime(buffer, 32, "%H:%M:%S", ptm);
    //cout << buffer;
    string ts;
    ts += buffer;
    return ts;
}



// ***********************************************************
//                     M A I N 
// ***********************************************************
// this function is called by setPower.pl
int main ( int argc, char **argv)
{
   cout << "Content-type:text/html\r\n\r\n";
   cout << "<html>\n";
   cout << "<head>\n";
   cout << "<title>RPI ECU PROGRAM</title>\n";
   cout << "</head>\n";
   cout << "<body>\n";
   cout << "<h4>running throttle.cgi</h4>\n";

   // we need an argument to know which inverter to throttle
   //string what;
   //string howMuch;
   if(argc > 1)
   {
       using std::atoi;
       which =atoi(argv[1]);
       //what = string(argv[1]);
       //cout << "there is an argument: which = " << which << "<br>" << endl;
       maxPower = atoi(argv[2]);
       //howMuch = string(argv[2]);
       //cout << "there is an argument: maxPower = " << maxPower << "<br>" << endl;
    } else {
       cout << "error: no inverternumber supplied \n<br>";
       return(3);
    }
    if( which > 8)
    {
      cout << "error: invalid inverternumber supplied \n<br>";
      return (4);
    }
     cout << "throttle running with arg "<< which << " and " << maxPower << "\n<br>" << endl;


   // initialize pigpio
    int gpio = ioInit();

// loop
    errorcode = sendCommand();
    cout << "returned by sendCommands() " << errorcode << "\n<br>" << endl;

// prepare the logging
    string toLog;
    if(errorcode == 0){
       toLog = "<br>" + thisTime() + " throttled inv " + to_string(which) + " to  "  +  to_string(maxPower);
    } else {
       toLog = "<br>" + thisTime() + " throttle inv " + to_string(which) + " failed !";
    }
    if (errorcode == 0) {
      serClose(fd);
      gpioTerminate();
      cout << "throttle exit with code 0\n<br>" << endl;

      cout << "toLog = " << toLog << "\n<br>" << endl;
      string logCmd ="echo \"" + toLog + "\" >> /ramdisk/ecu_log.txt";
      cout << "logCmd = " << logCmd << "\n<br>" << endl;
      system(logCmd.c_str());
      return 0;
  // we can mqtt and no log
  }

  switch(errorcode) {
  case 4:
       toLog += "error 4 no data received";
       break;
  case 5:
      toLog += "error 5 no inverterfile";
      break;
  case 6:
      toLog += "error 6 inverter not paired";
      break;
  case 7:
      toLog += "error 7 no ecu settings file";
      break;
  case 10:
      toLog += "error 10 AF_DATA_REQ fail";
      break;
  case 11:
      toLog += "error 12 no route receipt";
      break;
  case 12:
      toLog += "error 11 AF_DATA_CONFIRM fail";
      break;
  case 13:
      toLog += "error 10 AF_INCOMING_MSG fail";
      break;
  case 15:
      toLog += "error 15 message too short";
      break;
  case 16:
      toLog += "error 16 value doesn't match";
      break;

  case 100:
      toLog += "error 100 invalid energy value";
      break;

  }
  // if we are here, we set maxPower to -1 and 
  cout << "toLog = " << toLog << "\n<br>" << endl;
  string logCmd ="echo \"" + toLog + "\" >> /ramdisk/ecu_log.txt";
  cout << "logCmd = " << logCmd << "\n<br>" << endl;
  system(logCmd.c_str()); 
  
  writeFile(1); //write throttled = 0 and throtVal = -1
  
  serClose(fd);
  gpioTerminate();
  // if we are here the polling failed
  // we should make all the values 0 in the invDatafile
  // except for the energy values
  // in which cases we  dont have to make the file 0
  // not if not paired not if no ecu or inverter files 5 6 7
  // determined by the returnstatements in the switch
  if ( errorcode == 5 || errorcode == 6 || errorcode == 7 ) { 
  cout << "throttle exit (without resetting files) with code 1\n<br>" << endl;
  return 1;
}

     cout << "throttle exit with code 0\n<br>" << endl;
     return 0;
}

