// this program reads a zigbee message from command line
// adds slen and crc, sends it and reads the answer
// modifications dec 2023 : the buffersize in slen
// removed the delayMicroseconds on several places
// simplified the readZigbee and removed processIncomingByte 
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <errno.h>
//#include <wiringPi.h>
//#include <wiringSerial.h>
#include <iostream>
#include <fstream>
#include <sstream>
#include <pigpio.h>
#include </usr/lib/cgi-bin/ecu/libraries/serial_IOtest.h>

using namespace std;

//char s_d[254];

// with include seriaLIO.h we have the following functions
//int StrToHex(char str[])
//char *checkSum(char Command[])
//void sendZigbee(char sendString[] )
//bool waitSerialAvailable()
//char readZigbee(s_d) 




int main (int argc, char **argv)
{
   cout << "Content-type:text/html\r\n<html><head><title>RPI ECU PROGRAM</title></head><body>\n";
   cout << "<h4>running testZigbee.cgi version 2024-sep-2</h4>\n";

   char sendCmd[130]={""};
   //char bufferSend[254] ={0};

   if(argc > 1)
   {
        strncpy(sendCmd, argv[1], strlen(argv[1]));
   } else {
       cout << "error: no argument supplied\n<br>";
       return(3);
   }

    cout << "script testZigbee running with arg " << sendCmd << endl;
 
    
    int gpio = ioInit(); // init pigpto and open port serial0     
    sendZigbee(sendCmd);  
    gpioDelay(3000);
    (waitSerialAvailable()); 
//    char * inMessage = readZigbee(s_d);
    readZigbee();
    // retrieve an answer if there is one
//    char *inMessage = readZigbee(s_d);
    if(readCounter < 2) 
    {
       cout << "no answer\n<br>" << inMessage << endl;
    } 
  
 
    serClose(fd);
    gpioTerminate(); 
    return 0;

}


