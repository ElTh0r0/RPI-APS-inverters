<!DOCTYPE html><html><head><meta charset='utf-8'>
<title>ESP-ECU</title>
<meta name="viewport" content="width=device-width, initial-scale=1">
<link rel="icon" type="image/x-icon" href="/favicon.ico" />
<link rel="stylesheet" type="text/css" href="/STYLESHEET.css">
<link rel="stylesheet" type="text/css" href="/STYLESHEET2.css">
<script type='text/javascript'>

function helpfunctie() {
document.getElementById("help").style.display = "block";
}
function sl() {  
document.getElementById("help").style.display = "none";
}
function spinner(){
document.getElementById('loaderdiv').style.visibility = 'visible';
}

function hideLoader() {
document.getElementById('loaderdiv').style.visibility = 'hidden';
}

</script>
</head>
<body>

<div id='loaderdiv'><div class='loader'></div></div>

<div id='msect'>
  <div id="help">
  <span class='close' onclick='sl();'>&times;</span><h3>RECOVER HELP</h3>
For security reasons this page is only accessible from users in your own network.<br><br>

If you forgot the credentials for the website of your ECU<br>
you can wipe your wifi credentials too.<br><br>

After reboot the ECU will start the wifi accesspoint where you can re-enter all credentials.<br><br>

<br><br>In the screen below you can follow the process.<br><br>

</div>
</div>

<div id='msect'>
<div id='menu'>
<a href="/protected/menu.html" class='close'>&times;</a>
<a id='fleft' href='#' onclick='helpfunctie()'>help</a>
</div>
</div>
<div id='msect'>
<kop>RESET WIFI CREDENTIALS</kop>
</div>
<div id='msect'>
<center><div class='divstijl' >
<br>


<button id='wipebut' class='butt' onclick="actionFunction()">
wipe</button>


</div>
<iframe id='of' name='outputFrame' width='90%' height='250'></iframe>


<form id='wipe_cr' action='/cgi-bin/ecu/wifi/wipe_wificredentials.pl' style='display:none' target='outputFrame'></input></form>

</body>

<script>


function actionFunction() 
{

if(!confirm("This command will delete your wificredentials. At reboot the system will start the accesspoint radioAP ! ! ! \n\n Are you sure you want this? (see help)"))
       {
          location.reload() 
          return false;
       }
          // we change the visibility for the button
          document.getElementById("wipebut").style.visibility = 'hidden';

          spinner();
          checkReaction();   
          document.getElementById("wipe_cr").submit();
   


}

function checkReaction() {
  if(window.frames[0].document.body.innerHTML == "") {
     window.setTimeout(checkReaction, 500);
     } else {
     hideLoader();
   }
}

</script>
</html>