<!DOCTYPE html><html><head><meta charset='utf-8'>
<meta http-equiv="refresh" content="200">
<title>RPI-ECU</title>
<meta name="viewport" content="width=device-width, initial-scale=1">
<link rel="icon" type="image/x-icon" href="/favicon.ico" />
<link rel="stylesheet" type="text/css" href="/STYLESHEET.css">
<script type='text/javascript'>

function clearFunctie() {
if(!confirm("haha you would do that too, would you?")){
return false;}

document.getElementById("bo").innerHTML="<br>wait...<br>processing<br>your<br>request"; 
document.getElementById("bo").style.display="block"; 
//document.getElementById("clear").submit();
setTimeout(function(){window.location.href="LOGGING.php";}, 3000 ); 
}

var message = "viewing this page is disabled!";

function rtclickcheck(keyp){ if (navigator.appName == "Netscape" && keyp.which == 3){ alert(message); return false; }

if (navigator.appVersion.indexOf("MSIE") != -1 && event.button == 2) { alert(message); return false; } }

document.onmousedown = rtclickcheck;

</script>
<style>
.cap {
  font-weight:bold; 
  Background-color:lightgreen;
 }
div.overlay {
  display: block;
  width: 100%;
  height: 100%;
  background-color: rgba(0,0,0,0.7);
  z-index: 0;
  text-align: center;
  vertical-align: middle;
  line-height: 300px;
}

html {
  scroll-behavior: smooth;
 }

.inert{
   position: fixed;
   top: 0; 
   left: 0;
width:98%;
padding-left: 2px;
}
.datadiv {
  background: #e8edc8; 
  padding:0px 0px 0px 0px;
  width: 100%;
  height: 100%;
}
</style>
<script>
function scrollDown(){

document.getElementById('down').scrollIntoView(true);
}

</script>
</head>
<body onload="scrollDown()"><center>
<div class='inert'><center>
  <div id='msect' style="background: rgba(230, 247, 255, 1)";><center>
    <div id='bo'></div>
    <form id="clear" action="/cgi-bin/ecu/logClear.pl" target="hiddenFrame"> </form>
    <div id='menu'>
    <a id='fleft' href='#' onclick='clearFunctie()'>clear</a>
    <a id='fleft' href="#up" >up</a>
    <a id='fleft' href="#down">down</a>
    <a class='close' href='details.php'>&times;</a>
    </div>
   <kop>EVENTS JOURNAL</kop>
<br>  
</div>  

</div>


<div id='msect'><center>
<div class='datadiv' id='up' style="height: 100%;">
<center>
<div id='upper'></div>
<br><br><br><br>   
<br>
<?php

$filename="/ramdisk/ecu_log.txt";

if(file_exists($filename)) { 
$log = file_get_contents($filename);
} else {
goto error1;
}

echo $log;

goto phpend;

error1:
echo"<h1>currently no log exists, click done</h4>"; 
echo"</body></html><!--"; 

phpend:
?>
</div>
<div id='down'></div>
<iframe name='hiddenFrame' width='420' height='100' hidden></iframe>  

<br>

</body></html>
