<!DOCTYPE html>

<html lang="en" xmlns="http://www.w3.org/1999/xhtml">
<head>
    <meta charset="utf-8" />
    <title></title>
</head>
<body>
<style type="text/css">
#loading {
  width:100%;
  height:100%; /* height of 100% too*/
  position: absolute;
  left:0; top:0;
  background-color:rgba(192,192,192,0.9);
  color:white; 
  z-index:10;
  font-size: 60px;
  font-weight: bold;
  text-align: center;
  }
</style>
<script type="text/javascript">
    window.addEventListener("load", function(args){
        window.setTimeout(function () {
            document.getElementById("loading").style.display = "none";
        }, 2000);
    });
</script>

<div id='loading'><br>RPI-ECU<br>please wait<br>for the data <br> to be collected.. </div>
<button onclick="javascript:alert('OK')">Click Me</button>
  <div id='menu'>
  <a id='fleft' href='#' onclick='helpfunctie()'>help</a>

<?php
// read the invnr from the url
$invnr = $_GET['inv'];
echo "<a id='fleft' href='/AN_PERIOD.php?inv=" . $invnr . "'>period</a>";
echo "<a class='close' href='/chartjs/stats_e.php?inv=" . $invnr . "'>&times;</a>";

echo "</div>"; 

// these lines are to get the loading screen
ob_start();

$kat=10;
ob_end_flush(); // <--------------

ob_flush();
flush();


//first we read the start/enddate and inv nr in customQdate.txt
$file="/var/www/ecu_data/customQdate.txt";
if(file_exists($file)){
$fp = fopen($file, 'r');
$dat = fgets($fp);
$Bdatum = new DateTime("$dat");
$Bdatum = $Bdatum->format("Y-m-d");
$dat = fgets($fp);
$Edatum = new DateTime("$dat");
$Edatum = $Edatum->format("Y-m-d");
//$invnr = (int)fgetc($fp);
fclose($fp);
}

// we read the file invChoice.txt
//$invnr = file_get_contents("/ramdisk/invChoice.txt");

echo "<h2>statistical data inverter " . $invnr . "</h2></div><div id='msect'><div class='divstijl'><center>";

echo "<form id='formulier' method='post' action='writeQuerydates.php' target='hiddenFrame'>";


// **************************************************
//        we read the file settings.json
// **************************************************
// we also need the energy price from settings.json
$filename="/var/www/ecu_data/settings.json";
  if(file_exists($filename)) {
    $jsun = file_get_contents($filename);
    $urr = json_decode($jsun, true);
    $price = $urr["price"];
//    fclose($filename); not needed
} else {$price = 0;}

$currency = "&curren;";
// we have to read the currency sign
$filename="/var/www/ecu_data/currency.txt";
  if(file_exists($filename)) {
    $fp = fopen($filename, 'r');
    $cur = trim(fgets($fp));    
    fclose($fp);
    if($cur=="er"){
    $currency = "&euro;";
    } elseif ($cur=="do"){
    $currency = "&dollar;";
    } elseif ($cur=="po"){
    $currency = "&pound;";
    } 
   }  
// so if the file not exixts its always current

require 'cusQuery.php';
//echo "cusQuery has run<br>";
//echo "error = " . $error;
//$compare = "query invalid";
if ( $error == "invalid") {
echo "<br><br><h3>no data available</h3>";
goto error;
}

echo "<table><tr>";
//echo "<td style='border:none' colspan='2'><strong>timespan : " . $Bdatum . "</strong><td style='width:30px; text-align:center; border:none'> to <td style='border:none'><strong>" . $Edatum . "</strong></table>";

echo "<td style='border:none' colspan='2'><strong>timespan : " . $Bdatum . "  to  " . $Edatum . "</strong></table>";


echo"<table class='tab'>";
echo "<tr><td style='width:240px;'>";
echo "total count of days <td style='width:100px;'>" . $cnt . " days";
echo "<tr><td>";
if($sum > 1000) {
echo "total energy produced <td style='width:100px;'>" . number_format($sum/1000, 1, '.', '') . " KWh";
} else {
echo "total energy this period <td style='width:100px;'>" . number_format($sum, 2, '.', '') . " Wh";
}
echo " <tr><td> average energy per day<td> ". number_format($mean, 1, '.', '') .  " Wh</tr>";
$earn= $mean*$price/1000;
echo " <tr><td> average financial return<td> ". number_format($earn, 3, '.', '') .  " " . $currency . "</tr>";
echo "<tr><td> energy spread <td> " . number_format($spread, 2, '.', '');
echo "<tr><td> energy median <td> " . number_format($median, 2, '.', '');
echo "<tr><td> energy mode <td> " . number_format($mode, 2, '.', '');

echo "<tr><td> average power this period<td> " . number_format($meanP, 2, '.', '') .  " W</tr>";
echo "<tr><td> power peak (" . $whenhigh . ")<td> " . number_format($maxP, 2, '.', '') .  " W</tr>";
echo "<tr><td> max avg power (" . $whenhighavg . ")<td> " . number_format($maxavgP, 2, '.', '') .  " W</tr>";
echo "<tr><td> min avg power (" . $whenlowavg . ")<td> " . number_format($minavgP, 2, '.', '') .  " W</tr>";

error:
/*
echo '<script>
    document.getElementById("loading").style.visibility = "hidden";
}
</script>';
*/
?>
</table>


</body>
</html>