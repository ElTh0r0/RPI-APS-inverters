<!DOCTYPE html><html><head><meta charset='utf-8'>

<title>ESP-ECU</title>
<meta name="viewport" content="width=device-width, initial-scale=1">
<META HTTP-EQUIV="Content-Disposition" CONTENT="inline" />
<link rel="icon" type="image/x-icon" href="/favicon.ico" />
<link rel="stylesheet" type="text/css" href="/STYLESHEET.css">
<link rel="stylesheet" type="text/css" href="/STYLESHEET2.css">
<script type='text/javascript'>

function helpfunctie() {
document.getElementById("help").style.display = "block";
}
function sl() {  
document.getElementById("help").style.display = "none";
}

function hideLoader() {
document.getElementById('loaderdiv').style.visibility = 'hidden';
}

function refreshfunction() {
location.reload();
}


function restsubmit() {
          spinner();
          checkulReaction();   
          document.getElementById("restForm").submit();
   } 

function installsubmit() {
        if(!confirm("install backup settings and databases ! Are you sure?"))
       { 
          return false;
       }
          window.frames[0].document.body.innerHTML = ""; 
          spinner();
          checkinstallReaction();   
          document.getElementById("installform").submit();
   } 

function dummy(){
var q = 10;
 // do nothing
}
function readyfunction(){
window.location.href = "menu.html";
}
</script>
<style>
.inputfile {
	width: 0.1px;
	height: 0.1px;
	opacity: 0;
	overflow: hidden;
	position: absolute;
	z-index: -1;
}
.lbl {
border:3px solid black;
font-size:20px;
padding: 4px;
color: blue;
background-color:lightgrey;
border-radius: 8px;}
label:hover {
    background-color:red;
}</style>

</head>
<body>
<!-- the plan is to have a invisible div with the spinner. -->
<div id='loaderdiv'><div class='loader'></div></div>

<center>
 <div id='msect'>
 <div id="help">
  <span class='close' onclick='sl();'>&times;</span><h3>BACKUP / RESTORE HELP</h3>
  <b>PURPOSE:</b><br>
  With this tool you can restore all the settings and databases<br> if you made a backup 'ecu_backup.tar' <br>
<br><b>WHY:</b><br>
If there is a new softwareversion, you have to install a new sd-card image. <br>This means that you will lose all of your settings and data.<br><br>
<b>WHEN</b>
<br>If you install new software, it is best to do this during darkness, because there in no activity in the ECU.<br>Just before upgrading you make a backup of your settings first. <br><br>
<b>RESTORE:</b><br>Click the file select button. You can select a backup file. ATTENTION check the properties of the file to be shure that you upload the right file.<br>You can only select a file that is named 'ecu_backup.tar'.
Click the submit button. Now the file is uploaded to your ecu, and a install button will reveal.<br>
Click this to complete the restore. All settingsfiles and databases will be restored .<br>
<br>In the frame below you can follow the process.
  <br><br>
  </div>
</div><div id='msect'>
<div id='menu'>
<a id='fleft' href='#' onclick='helpfunctie()'>help</a>
<a href="DBASE.php" class='close'>&times;</a>
</div></div>
<div id='msect'>
   <h2>RPI-ECU RESTORE DATABASE</h2>
</div><div id='msect'>
<div class='divstijl' >
<center>

<div id="okdiv" style='display:none; position:relative;
  top: 30px;' >
The installation script has run, check the results below and click OK<br>
<br>
<button type='button' class= 'butt' onclick='readyfunction()'>OK</button>
</div>

<div style='border:1px solid; display:block' id='formdiv'>
  <br>
  <form id="restForm" method="post" enctype="multipart/form-data" action="upload.php" target='hiddenFrame'>

  <div>
<label id='laBel' for='fileToUpload' class='lbl'>choose a file</label>

<input type='file' name="fileToUpload" id="fileToUpload" accept ='.tar' required='required' oninput='showButton()' class='inputfile'></div>
  </form>
<h3><div id='show'></h3></div>
<br>

  <div id='subButton' style='display:none'><button class= 'butt' type='button' name='haha' onclick='restsubmit()'>upload</button><br><br></div>


<form id='installform' target='hiddenFrame' action='/cgi-bin/ecu/dbRestore.pl'></form>
<div id ="installdiv" style='display:none'>
To complete the installation of the restore, click install<br><br>
<button type='button' class= 'butt' onclick='installsubmit()'>install</button><br><br>
</div>


<br><br>


<br>

<iframe name='hiddenFrame' height='200'></iframe>  

<script>
function spinner(){
document.getElementById('loaderdiv').style.visibility = 'visible';
}

function checkinstallReaction() {
//console.log("a = " + a);
//spinner();
window.frames[0].document.body.innerHTML == ""; 
if(window.frames[0].document.body.innerHTML == "") {
   window.setTimeout(checkinstallReaction, 500);
   } else {
     hideLoader();
//hide the form including the install button, 
//insteat show another form
document.getElementById("formdiv").style.display="none";
document.getElementById("installdiv").style.display="none";
document.getElementById("subButton").style.display="none";
// show an ok button
document.getElementById("okdiv").style.display="block";
  }
}

function checkulReaction() {
//spinner();
if(window.frames[0].document.body.innerHTML == "") {
   window.setTimeout(checkulReaction, 500);
   } else {
   hideLoader();
var reaction = window.frames[0].document.body.innerHTML; 
console.log(reaction);
if( reaction.indexOf("Error") == -1){
document.getElementById("installdiv").style.display="block";
document.getElementById("subButton").style.display="none";
document.getElementById("formdiv").style.display="none";

   } else {
alert("An error occurred, please try again");
   refreshfunction();
   }
  }
}

function showButton() {
var hihi = document.getElementById("fileToUpload").value;
var hoho = hihi.replace(/^.*\\/, "");
//alert("value = " + hoho);
document.getElementById("show").innerHTML=hoho;

//var hoho=document.getElementById("fileToUpload").value;
//alert("showbutton " + hoho);
if(hoho == "") {
alert("you didn't choose a file, try again");
refreshfunction();
} else {
document.getElementById("subButton").style.display="block";
}
}
</script>


</body></html>