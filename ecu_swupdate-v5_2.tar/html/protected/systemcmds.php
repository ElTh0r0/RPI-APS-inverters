<?php
$debugfile = "/var/www/ecu_data/debugstatus.txt";
$debugValue = trim(file_get_contents($debugfile));
$debug = ($debugValue !== "0");
?>

<!DOCTYPE html><html><head>
<title>hansiart RPI ECU</title>
<meta name="viewport" content="width=device-width, initial-scale=1">
<link rel="shortcut icon" type="image/png" href="/favicon.ico"/>

<link rel="stylesheet" type="text/css" href="/STYLESHEET.css" />
<link rel="stylesheet" type="text/css" href="/STYLESHEET2.css">


<style>
  .hide { position:absolute; top:-1px; left:-1px; width:1px; 
   height:1px; 
  }

  td {position : relative;
    height: 45px;
    }
 .butt {
    width: 180px;
}   

</style>

<script type='text/javascript'> 

var debug = <?php echo $debug ? 'true' : 'false'; ?>;
console.log("debug = " + debug);
function init() {
if(debug) {
document.getElementById('debugFr').style.display = 'block';
  }
}


function systemHalt() {
if(confirm('system halt, are you sure?')) {
  spinner();
  checkReaction();   
  document.getElementById('haltknop').submit();
}
else {
  alert("shutdown gecanceld"); 
  return false; } 
}

function systemReboot() {
if(confirm('system reboot, are you sure?')) {
  spinner();
  checkReaction();   
  document.getElementById('rebootknop').submit();
}
else {
     alert("reboot cancelled"); 
     return false; } 
}

function fsExpand() {
if(confirm('expand filesystem, are you sure?')) {
var iframe = document.getElementById('debugFr');
iframe = iframe.contentWindow || ( iframe.contentDocument.document || iframe.contentDocument);

iframe.document.open();
iframe.document.write('<br>the filesystem is going to expand, please wait, this may take some time!');
iframe.document.close();
document.getElementById('expandknop').submit();
}
else {
     alert("expand filesystem canceled"); 
     return false; } 
}


function spinner(){
document.getElementById('loaderdiv').style.visibility = 'visible';
}


function checkReaction() {
if(window.frames[0].document.body.innerHTML == "") {
   window.setTimeout(checkReaction, 500);
   } else {
     hideLoader();
     //document.getElementById("dldiv").style.visibility="visible";
  }
}

function hideLoader() {
document.getElementById('loaderdiv').style.visibility = 'hidden';
}

</script>

</head>
<body onload='init()'>
<!-- the plan is to have a invisible div with the spinner. -->
<div id='loaderdiv'></div>


<div id='msect'><center>   
<div id='menu'>
<a id='fleft' href='settimezone.php'>timez</a>
<a id='fleft' href='ip_config.php'>wifi</a></li>
<a id='fleft' href='PASSWORD.php'>passwd</a>
<a id='fleft' href='SWUPDATE.php'>update</a>
<a href="menu.html" class='close'>&times;</a>
</div>
<br>
<kop>  HANSIART RPI ECU </kop>
<div class='divstijl' style='font-size:16px;'>
<center><h4>SYSTEM COMMANDS</h4>




<form method="post" id='rebootknop' target='hiddenFrame' action="/cgi-bin/ecu/system/reboot.pl">
<button type='button' id='rb' name='rb' onclick='systemReboot()' class='butt'>system reboot
</button></form>


<tr><td><td>
<form method="post" id='haltknop' target='hiddenFrame' action="/cgi-bin/ecu/system/shutoff.pl">
<button type='button' id='so' name='so' onclick='systemHalt()' class='butt'>system halt
</button></form>
</tr>


<?php
// read the file to see if the expand button is needed.
$file = fopen("/var/www/static_data/expand.txt","r");
     $expand = fgetc($file);
     fclose($file);
if ( $expand != "y" ){     
echo"<tr><td><form method='post' id='expandknop' target='hiddenFrame' action='/cgi-bin/ecu/system/expand.pl'>
<button type='button' id='exp' name='exp' onclick='fsExpand()' class='butt'>expand fs</button></form></tr></table>";
}
?>

</table>

<center><iframe id='debugFr' name='hiddenFrame' width='90%' height='200'></iframe>
<br>
</div>
</body>
</html> 
