<!--
* * * * * * * *  revision log * * * * * * * * * * 
2024-09-03: changed the disk info (no longer read from a file)
changed the memory info (wrong data extraction)
removed help menu
-->
<html>
<head>
<meta name='viewport' content='width=device-width, initial-scale=1' />
<link rel="icon" type="image/x-icon" href="/favicon.ico" />
<link rel="stylesheet" type="text/css" href="/STYLESHEET.css" />
<style>
table, th, td {
  border: 1px solid black;
}
td {
width:70px;
text-align:center;
}
</style>
</head>

<body><center>
<div id="msect"><center>
<div id='menu'>
<!--<a href='/index.php'>home</a>-->

<a href="menu.html" class='close'>&times;</a>
</div></div><br>
<div id='msect'><center>
<kop>  HANSIART RPI ECU </kop>
<div class='divstijl' style='font-size:16px;'>

<h4>RPI ECU SYSTEM INFORMATION</h4>

<?php
$ip_server = $_SERVER['SERVER_ADDR'];

// Collect the Data first
// we read the file swVersion.txt
$fp = fopen('/var/www/static_data/swVersion.txt', 'r');
$version = fgets($fp);
fclose($fp);
echo "firmware version =  $version <br>";
echo "this IP Address is: $ip_server<br>";
// Get uptime info from system call to uptime
$uptime = exec("/usr/bin/uptime");
$tijd = substr($uptime,0, 9);
echo "systemtime = " . $tijd . "<br>";

$rest = substr($uptime,9 );
//echo "rest = " . $rest . "<br>";
// als geen dagen dan is rest: up 2:16, 2 users, load average: 0.20, 0.13, 0.14 en dan zijn er 5 elementen
$myarray = (explode(",", $rest));
$num_tags = count($myarray);
if($num_tags==5) {
//de up informatie bestaat uit uren en min
$myarray2 = (explode(":",$myarray[0]));
echo "uptime = " . $myarray2[0] . "hr " . $myarray2[1] . "min.<br>";
} else {
//er zijn nu 6 elementen, element 0= "up 2 days"
//de up informatie ziet er zo uit up 2 days, 10:20
//dagen zitten in nu in element 0
//echo "myarray[0]= ". $myarray[0];
$dagen = substr($myarray[0],3);
$dagen = substr($dagen, 0, -4);
//echo "dagen = ". $dagen;
$myarray2 = (explode(":",$myarray[1]));
//echo "rest = " . $rest;
echo "uptime = " . $dagen . "days " . $myarray2[0] . "hr " . $myarray2[1] . "min. <br>";

}
//echo "usercount" . $myarray[$num_tags-4] . "<br>";  //aantal users

$myarray3 = substr($myarray[$num_tags-3], 15);
echo "av. cpu occupation : " . $myarray3. " " . $myarray[$num_tags-2] . " "  .  $myarray[$num_tags-1] . "<br>";


// *********************   temperature ******************
$temperature = exec("cat /sys/class/thermal/thermal_zone0/temp");
$hele = substr($temperature, 0, 2);
$digs = substr($temperature, 3, 4);
echo "core temperature " . $hele . "." . $digs ."&degC<br><br>";

// *********************   memory ******************
$mem = shell_exec("free --mega | grep Mem");
$memitems = explode(" ", $mem);
echo"<table><tr><td style='width:190px;'>Memory usage<td>Total<td>used <td>Free</td></tr><tr><td>Mb's";
$hits = 0;
// print the array items, skip if empty, "Mem: or > 3
foreach($memitems as $v){
if ($v != '' && $v != 'Mem:' && $hits <3) { 
   echo "<td> ". $v . "</td>";
   $hits += 1;
   }
}
echo "</table>";
echo "<br>";

// *********************   disk info ******************
$disk = shell_exec("df -h | grep /dev/mmcblk0p2");
//echo "<br>current sd-card usage:<br> ";
echo"<table><tr><td>filesystem<td>size <td>used <td>available <td>use %</td></tr>";
$items = explode(" ", $disk);
$removed = array_pop($items); // remove the last element
// print the array items, skip when empty
foreach($items as $v){
if ($v != '') { echo "<td> ". $v . "</td>";}
}
echo "</table>";
echo "<br>";
// ************  end disk info *************
$filename = '/var/www/ecu_data/startstop.txt';

$file = fopen($filename ,"r");
$start = fgets($file);
$stop = fgets($file);
$rise = fgets($file);
$set = fgets($file);
//fclose($file);
 
echo "sunrise is at : " . $rise . " and sunset is at " . $set;
echo "<br>polling starts at: " . $start . " and stops at " . $stop;

?>


</span>
<br><br><span style='color: green; font-size: 12px;' class="groen">
<!--Tip: De timer blijft actief totdat op "disarm" is gedrukt.-->
</span>
<br>
</div>

</div>
<br><br>

</body>
</html> 
