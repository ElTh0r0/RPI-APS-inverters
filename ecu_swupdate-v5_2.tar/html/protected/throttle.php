<?php
$debugfile = "/var/www/ecu_data/debugstatus.txt";
$debugValue = trim(file_get_contents($debugfile));
$debug = ($debugValue !== "0");
?>

<!DOCTYPE html><html><head><meta charset='utf-8'>
<title>RPI-ECU</title>
<meta name="viewport" content="width=device-width, initial-scale=1">
<link rel="icon" type="image/x-icon" href="/favicon.ico" />
<link rel="stylesheet" type="text/css" href="/STYLESHEET.css">
<link rel="stylesheet" type="text/css" href="/STYLESHEET2.css">
<script type='text/javascript'>
var repeat = 0;
var debug = <?php echo $debug ? 'true' : 'false'; ?>;
console.log("debug = " + debug);
function init() {
if(debug) {
document.getElementById('debugFr').style.display = 'block';
  }
}
function helpfunctie() {
document.getElementById("help").style.display = "block";
}
function sl() {  
document.getElementById("help").style.display = "none";
}
function showSubmit(a) {
var but = document.getElementById("btn" +a);
//alert("but = " + but); 
if(repeat==0) {
  but.style.display = "block";
  repeat = 1;
  }
}
function submitFunction(a) {
var term = "form" + a;
alert("saving "+ term);
document.getElementById(term).submit();
if(!debug) {
   setTimeout(function(){window.location.href='throttle.php';}, 3000 ); 
  } 
}

function spinner(){
//alert("spinner");
document.getElementById('loaderdiv').style.visibility = 'visible';
}
</script>
<style>
body {
 background-color: #EEE;
}

table, th,  {
  border: 1px solid blue;
 border-collapse: collapse;
  font-size:14px; 
  padding:2px;
  }


.c0, .c1, .c2, .c3 { border:none }
.c0 {width: 15%}
.c1 {width: 35%; padding-right:0px;}
.c2 {width: 25%; padding-left:2px;padding-right:8px;}

.lijn3 {
borders:none;
border-bottom:1px solid black; 
height: 1px;
}

tr {height:38px;}

.linkbt {
  width: 100%;
  height: 40px;
  border-radius: 10px;
  border: solid 1px black;
  box-shadow:  2px 2px 4px black; /*r u u d */
  padding: 0px 2px;
  text-align: center;
  text-decoration: none;
  display: inline-block;
  font-size:14px;
  font-weight: bold;
  background-image:
    radial-gradient(
      rgb(255, 255, 0), 
      #004d00 80%
    );
  color: black;
overflow:hidden; 
}
.linkbt:hover {background-image: linear-gradient(red, yellow, green);}

.linkbt:active {
  background-color: #3e8e41;
  box-shadow: 0 5px #666;
  transform: translateY(4px);
}

a {
  text-decoration: none;
  color: green;
}

.nm {
  width:140px;
  font-size:20px;
  font-weight: bold;
  text-align: center;
  border: none;
  }

.haha {
Background-color:#e6b3cc;   
font-weight:bold; 
font-size:18px; 
text-align:center;
}
.hihi , .hihi2 {
border-collapse: collapse;
font-size:18px; 
text-align:center;
font-weight:bold; 
}
.hihi2 {Background-color:#e6b3cc; }  

input {text-align:center}

</style>

<!--<SCRIPT language=JavaScript>

var message = "viewing this page is disabled!";

function rtclickcheck(keyp){ if (navigator.appName == "Netscape" && keyp.which == 3){ alert(message); return false; }

if (navigator.appVersion.indexOf("MSIE") != -1 && event.button == 2) { alert(message); return false; } }

document.onmousedown = rtclickcheck;

</SCRIPT>
-->

</head>
<body style="font-family: 'lato',Verdana,Sans-serif;font-size:16px;" onload='init()'><center>
<div id='loaderdiv'><div class='loader'></div></div>

<center>

<div id='msect'>
  <div id='help'>
  <span class='close' onclick='sl();'>&times;</span><h3>THROTTLE INVERTERS HELP</h3>
  <b>function:</b><br>
  To set a value for the maximum output (per channel) of an inverter.<br>This can be usefull if delivery to the grid is unwanted.
  
<br><br><b>validation</b><br>
  Currently not every type of inverter can be throttled. In case it failes you'l see the value of -1.

  <br><br><b>warning</b><br>
  This function is disabled during nighttime, the inverter is not online then. The screen is dark when this is the case.
    <br><br>
  </div></div>


<div id='msect'>
<div id='menu'>
<a href="/index.php" class='close'>&times;</a>
<a id='fleft' href='#' onclick='helpfunctie()'>help</a>
<a id='fleft' href='/LOGGING.php'>journal</a>
<a id='fleft' href=# onclick='location.reload();'>refresh</a>
</div>
</div>



<div id='bo'></div>
<kop>RPI-ECU THROTTLE INVERTERS</kop>

<?php

//we first need to know if it is nighttime
//we can check if exists /ramdisk/sleepFlag.txt
$fn = "/ramdisk/sleepFlag.txt";
if(!file_exists($fn)) {
 $bac="linear-gradient(#e8edc8, #c8eaed)"; $clr="green";
} else { 
$bac="grey"; $clr="white"; $blur = $red = $blue = 0;
}

echo "<div class='divstijl' style='background:" . $bac . ";height:78vh; padding-top: 0px;'><center>";

# *****************************************************
# *    TABLE START                                    *
# *****************************************************

echo "<center><table style='width: 100%; border:1px solid black; background-color:#d1d1e0;box-shadow: 0px 0px ". $blur . "px 2px rgb(". $red . ", 0, " . $blue . ");'>";

echo"<tr style='font-weight:bold; font-size:14px; text-align:center; border:none;'><td class='c0'>inv #<td class='c1'> name<td class='c2'>throttle<td class='c2'>save</td></tr>";

echo "<tr class='lijn3'><td class='lijn3' colspan='100%'></td></tr>";
/*
# *****************************************************
# *    READING throttle.json                *
# *****************************************************
*/
$count=0;
// **************************************************
//        we read the file invCount.txt
// **************************************************
$fp = fopen('/var/www/ecu_data/inverterCount.txt', 'r');
$invCount = (int)fgetc($fp);
fclose($fp);

//echo "invCount = " , $invCount;
// some empty rows depending on invCount
for ( $x=0; $x < 5-$invCount; $x++ ) { echo "<br>"; }

$filename="/var/www/ecu_data/inverters/throtvals.json";
// Load JSON file
if (file_exists($filename)) {
    $raw = file_get_contents($filename);
    $data = json_decode($raw, true); // decode to associative array
//echo "$data = " . $data;
} else {
    $data = []; // fallback if file doesn't exist
}

for($x = 0; $x < 10; $x++){

# pick the available inverters
    $key = "inv" . $x;
    if (isset($data[$key])) {
        //echo "$key = " . $data[$key] . PHP_EOL;
        $throtVal = $data[$key];   
        //echo "throtVal = " . $throtVal . PHP_EOL;
     } else { $throtVal = "-1"; }

$filename="/var/www/ecu_data/inverters/invProperties" . $x;
if(file_exists($filename)) {
$count++;
// we read the name from invProperties
$jsan=file_get_contents($filename);
$orr = json_decode($jsan, true);
$name = $orr["name"];
  
echo "<tr style='font-weight:bold; font-size:14px; text-align:center;'><td class='c0'>" . $x;
echo "<td class='c1'>" . $name;

echo "<form id='form" . $x . "' method='get' action='/cgi-bin/ecu/throttleSave.pl' target='hiddenFrame'>";

echo "<td class='c2'><input class='inp2' name='pMax' id='pmax" . $x . "' type = 'number' min='0' max='600' step='5' value='" . $throtVal . "' oninput='showSubmit(" . $x . ")'></input>";

echo "<input class='inp2' name='inv' value='" . $x . "' id='pmax" . $x . "' type = 'hidden' ></input>";

echo "<td class='c2'><button id='btn" . $x ."' class='linkbt' style='display:none' onclick='submitFunction(" . $x . ")'>submit</button></form>";    

 echo "<tr class='lijn3'><td class='lijn3' colspan='100%'></td></tr>";
    
  }
}
// **********   T O T A L S **********
// only if invcount > 1

echo "</table>";

if($invCount == 0){
echo"<center><br><br><br><h3>currently no inverters registered!</h3>";
}
// some empty rows depending on invCount
for ( $x=0; $x < 5-$invCount; $x++ ) { echo "<br>"; }

echo "<pre><span style='color:" . $clr . "'>Powered by Hansiart</span></pre>";
?>
</div>

<br><center><iframe id='debugFr' name='hiddenFrame' width='420' height='400' hidden></iframe>  

</body>
 </html> 
