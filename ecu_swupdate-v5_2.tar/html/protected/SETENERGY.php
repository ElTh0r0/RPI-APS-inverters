<!DOCTYPE html><html><head><meta charset='utf-8'>
<title>ESP-ECU</title>
<meta name="viewport" content="width=device-width, initial-scale=1">
<link rel="icon" type="image/x-icon" href="/favicon.ico" />
<link rel="stylesheet" type="text/css" href="/STYLESHEET.css">
<link rel="stylesheet" type="text/css" href="/STYLESHEET2.css">
<script type='text/javascript'>

function helpfunctie() {
document.getElementById("help").style.display = "block";
}
function sl() {  
document.getElementById("help").style.display = "none";
}

function hideLoader() {
document.getElementById('loaderdiv').style.visibility = 'hidden';
}

function refreshfunction() {
location.reload();
}

</script>
</head>
<body>
<!-- the plan is to have a invisible div with the spinner. -->
<div id='loaderdiv'><div class='loader'></div></div>

<div id='msect'><center>
  <div id="help">
  <span class='close' onclick='sl();'>&times;</span><h3>EDIT ENERGY DATABASE HELP</h3>
With this utility you can delete / replace an energy value in the database 'invEnergy'.<br>
Use this in case of wrong date in the daily energy chart.
<br><br>
<b>purpose</b><br>Remove or replace the energy value for a specific date from the database 'invEnergy'
<br><br> 
<b>usage</b><br>
- choose an inverternr in the 1st selectbox.<br>
- choose the date in the next selectbox.<br>
- write a new value (Wh e.g. 1500 = 1.5kWh) in the new value field.
<br><br>
If you don't provide a new energy value, the old value will be deleted.

<br><br>In the screen below you can follow the process.<br><br>
</div>

<div id='menu'>
<a id= 'fleft' href='#' onclick='helpfunctie()'>help</a>
<a href='#' id="sub" onclick='submitFunction()'>save</a>
<a href="DBASE.php" class='close'>&times;</a>

</div>

<kop>RPI-ECU EDIT ENERGY DATABASE</kop>
<div class='divstijl'><center>

<div id='refreshdiv' style='display:none; z-index: 10;'><button class='butt' onclick='refreshfunction()'>send another command</button></div>

<div id='formDiv' style='display:block'>
<form id='setValue' action='/cgi-bin/ecu/setEnvalue.pl' target='outputFrame' oninput='showSubmit()'>
<table><tr><td>inverter<td>
<select name='ivnr' id='ivnr' class='sb3'>
<option selected readonly>CHOOSE INVERTER</option>

<?php
// we read the file qinvChoice.txt for inv nr and date
$file="/var/www/ecu_data/qinvChoice.txt";
if(file_exists($file)){
$fp = fopen('/var/www/ecu_data/qinvChoice.txt', 'r');

$dat = fgets($fp);
$invnr = (int)fgetc($fp);
$datum = new DateTime("$dat");
$datum = $datum->format("Y-m-d");
fclose($fp);
} else {
$datum = date('Y-m-d');
$invnr = 0;
$klik = 1;
}

for($x = 0; $x < 10; $x++){
# pick the available inverters
$sel = "";

$filename="/var/www/ecu_data/inverters/invProperties" . $x;
  if(file_exists($filename)) {
    $jsan = file_get_contents($filename);
    $orr = json_decode($jsan, true);
    $name = $orr["name"];
    
    if($invnr == $x) {$sel = "selected";}   
    echo "<option " . $sel . " value='" . $x . "'>" . $x ." " . $name . "</option>";
   } 
}
echo"</select><tr><td>date:<td>";
echo"<input type='date' id='dat' name='datum' value='" . $datum . "' ></input>";


?>
<br></td></tr>

<tr><td>value<td><input name='env' id='env' class='inp5'>
</td></tr></table>

</form>
</div>

<iframe id='of' name='outputFrame' style='height:340px; margin-bottom:10px;'></iframe>

</body>

<script>
function showSubmit() {
document.getElementById("sub").style.display = "block";
}

function submitFunction() {
alert("submit");
if(!confirm("check your input! Are you sure it's oke?")){
   return false;
   }

if(document.getElementById('ivnr').value=="CHOOSE INVERTER") {
alert("you forgot to provide an inverter");
return;}
var waarde = document.getElementById('env').value;

if(waarde.indexOf(".") > -1 || waarde.indexOf(",") > -1 ) {
alert("input Wh, decimal point forbidden");
return;}


document.getElementById('formDiv').style.display = 'none';
document.getElementById("refreshdiv").style.display = 'block';
spinner();
checkReaction();   
document.getElementById('setValue').submit();
}

var ikeuze;


function spinner(){
document.getElementById('loaderdiv').style.visibility = 'visible';
}


function checkReaction() {
//spinner();
if(window.frames[0].document.body.innerHTML == "") {
   window.setTimeout(checkReaction, 500);
   } else {
   hideLoader();
}
}

</script>
</html>