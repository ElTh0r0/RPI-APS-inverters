<!DOCTYPE html><html><head><meta charset='utf-8'>
<title>RPI-ECU</title>
<meta name="viewport" content="width=device-width, initial-scale=1">
<link rel="icon" type="image/x-icon" href="/favicon.ico" />
<link rel="stylesheet" type="text/css" href="/STYLESHEET.css">
<link rel="stylesheet" type="text/css" href="/STYLESHEET2.css">
<script type='text/javascript'>

function helpfunctie() {
document.getElementById("help").style.display = "block";
}
function sl() {  
document.getElementById("help").style.display = "none";
}

function hideLoader() {
//alert("hiding loader");
document.getElementById('loaderdiv').style.visibility = 'hidden';
}

function refreshfunction() {
location.reload();
}

</script>
<style>

.sb5 {
   font-size:20px;
   height:29px;
   width:100px;
  } 
@media only screen and (max-width: 500px) {
.sb5 {height:24px;}
}
</style>
</head>
<body>

<!-- the plan is to have a invisible div with the spinner. -->
<div id='loaderdiv'><div class='loader'></div></div>


<center>

<div id='msect'>
  <div id="help">
  <span class='close' onclick='sl();'>&times;</span><h3>CONSOLE HELP</h3>
This console is a very powerfull instrument to debug the various processes of the system.<br><br>
<b>usage</b><br>
- Enter an argument, e.g. a command or an inverternr in the attribute field.<br>
- Choose an action<br>
The action will be processed and the output appears in the frame.
<br><br>
<b>factory reset</b><br>
All inverter settings/databases are removed. Individual inverters can be deleted via the inverters menu. Their database can be deleted via the database menu.<br><br>
<b>zigbee commands explanation</b><br>
A command exists of FE, length(1byte), command (2 bytes), data (x bytes) and checksum.<br>
In the field you only have to enter the command bytes and data if applicable (eg 410000).<br><br>
  <b>commands and answers:</b><br>
  2700 test if the coordinator is running<br>
answer FE0E670000FFFF80971B01A3D6FEFF<mark>070000</mark>17: <br> ready but needs to be started ( command 2600)<br>

answer FE0E670000FFFF80971B01A3D6FEFF<mark>070900</mark>17: running
<br>
2100 ping
answer 
<br><br>In the screen below you can follow the process.<br><br>

</div></div>
<div id="msect">

<div id='menu'>
<a id='fleft' href='#' onclick='helpfunctie()'>help</a>
<a href="menu.html" class='close'>&times;</a>
</div></div>
<div id='msect'>
<h2>RPI-ECU CONSOLE</h2>
</div>
<div id='msect'>

<center><div class='divstijl'>
<br>
<table><tr><td>
<div id='formDiv' style='display: block;'></>
<select id='sel' class='sb5' name"actionSelect" onchange="actionFunction()">
<option selected readonly>action</option>
<option value='1'>start coordinator for normal</option>
<option value='0'>send zigbee command</option>
<option value='2'>run health check coordinator</option>
<option value='3'>query an inverter</option>
<option value='5'>poll an inverter</option>
<option value='7'>remove wifi credentials</option>
<option value='6'>factory reset</option>
<option value='8'>set debug</option>
</select>
<td><input name='cmd' id='com' placeholder='attribute' class='inp6'></input>
</div>
</table>
<br>

<div id='waitDiv'></div>

<iframe id='of' name='outputFrame' width='90%' height='410'></iframe>

<br></div></div>
<form id='initN' action='/cgi-bin/ecu/startCoordinator.pl' style='display:none' target='outputFrame'><input name="normal" value='1'></input></form>

<form id='query' action='/cgi-bin/ecu/inverterQuery.pl' style='display:none' target='outputFrame'><input id='whichQuery' name='welke'></form>

<form id='health' action='/cgi-bin/ecu/checkCoordinator.pl' style='display:none' target='outputFrame'></form>

<form id='reset' action='/cgi-bin/ecu/resetScript.pl' style='display:none' target='outputFrame'></input></form>

<form id='test' action='/cgi-bin/ecu/sendZigbee.pl' style='display:none' target='outputFrame'><input id='testCmd' name='cmd'></input></form>

<form id='poll' action='/cgi-bin/ecu/inverterPoll.pl' style='display:none' target='outputFrame'><input id='welkePoll' name='welke'></input></form>

<form id='wipe_cr' action='/cgi-bin/ecu/wifi/wipe_wificredentials.pl' style='display:none' target='outputFrame'></form>

<form id='set_debug' action='/cgi-bin/ecu/debug_conf.pl' style='display:none' target='outputFrame'><input id='debugyn' name='debugyn'></input></form>
</body>

<script>

function spinner(){
document.getElementById('loaderdiv').style.visibility = 'visible';
}

function actionFunction() 
{
// first read the values of the form before they disappear
var b=document.getElementById("sel").value;
var command=document.getElementById('com').value;
console.log("com = " + command);
var length = command.length;

// we change the innerHTML of the form, the inputs are replaced
// with the refreshbutton 
document.getElementById("formDiv").innerHTML="<button class='butt' id='focusbut' onclick='refreshfunction()'>send another command</button><br>";   

//document.getElementById("focusbut").focus();
   
   if(b==3) 
   {
      if(length != 1 || isDigit(command)== false ){
             alert("you should provide valid data ( 0 to 8)");
             location.reload();
          } else {
             //console.log("command = " + command);
             spinner();
             document.getElementById("whichQuery").value=command;
             //alert("command = " + command);
             checkReaction();   
             document.getElementById("query").submit();
          }
         
    }
   if(b==1) 
   {
       if(!confirm("are you sure to start the coordinator? (WARNING this can take a minute)"))
       {
          location.reload();
          return false;
       } else {
          spinner();
          checkReaction();   
         document.getElementById("initN").submit();
       } 
    }

   if(b==2)  // health
   {
       if(!confirm("are you sure to check the coordinator ?"))
       {
          location.reload();
          return false;
        } else {
          spinner(); 
          checkReaction();
          document.getElementById("health").submit();
       } 
   }
   
   if(b==0) // send zigbee command
   {
      var islow = hasLowerCase(command);
      if( length < 4 || islow==true  ) 
      {
  alert("you should provide valid data ( length > 4, only digits and uppercase letters) " + length);
        location.reload();
      } else {
        spinner();
        checkReaction();
        document.getElementById("testCmd").value=command;
        document.getElementById("test").submit();
        //return false;
       } 
   }
   

   if(b==5) // poll an inverter command 
   {
   
   if(length != 1 || isDigit(command)== false ){
   
    alert("you should provide valid data ( 0 to 8)");
     location.reload();
      } else {
      spinner();   
      document.getElementById("welkePoll").value=command;
      //alert(" b = " + b + " value = " + command);
      checkReaction();
      document.getElementById("poll").submit();
      } 
   }

   if(b==6) // factory reset
   {
       if(!confirm("This command will delete all inverters and all database entries! ! ! Are you sure to do this? (see help)"))
       {
          location.reload() 
          return false;
       }
        if(!confirm("FACTORY RESET: all inverter settings and databases entries will deleted ! ! ! Are you REALLY VERY sure you want this?"))
       {
          location.reload() 
          return false;
       }
          spinner();
          checkReaction();   
          document.getElementById("reset").submit();
   } 

   if(b==7) // remove wifi credentials 
   {
       if(!confirm("This command will delete your wificredentials. At reboot the system can't connect to your wifi anymore and will start the accesspoint radioAP ! ! ! \n\n Are you sure you want this? (see help)"))
       {
          location.reload() 
          return false;
       }
          spinner();
          checkReaction();   
          document.getElementById("wipe_cr").submit();
   } 


   if(b==8) 
   {
      if(length != 1 || isDigit(command)== false ){
             alert("you should provide valid data ( 0 or 1)");
             location.reload();
          } else {
             if(command != 0) {command = 1};
             //console.log("command = " + command);
             //alert("command = " + command);
             spinner();
             document.getElementById("debugyn").value=command;
             //alert("command = " + command);
             checkReaction();   
             document.getElementById("set_debug").submit();
          }
         
    }



}
var isDigit = (function() {
    var re = /^\d$/;
    return function(c) {
        return re.test(c);
    }
}());

function hasLowerCase(str) {
    return (/[a-z]/.test(str));
}

function checkReaction() {
//spinner();
if(window.frames[0].document.body.innerHTML == "") {
   window.setTimeout(checkReaction, 500);
   } else {
   hideLoader();
 }
}

</script>
</html>
