<!DOCTYPE html><html>
<head>
<meta name='viewport' content='width=device-width, initial-scale=1' />
<link rel="shortcut icon" type="image/png" href="/favicon.ico"/>
<link rel="stylesheet" type="text/css" href="/STYLESHEET.css" />
<link rel="stylesheet" type="text/css" href="/STYLESHEET2.css" />
<style>
.inp7 {
    font-size:24px; 
    }
.inp1 {
    font-size:20px;
    width: 156px; 
    }

.knop {
  font-size: 12px;
  height: 30px; 
  background-color:#330066; 
  color:#99ffff; 
  padding: 5px 8px; 
  border-radius:8px;
  }

table, th {text-align: center;}

td {
position: relative;
}
.switch {
  position: relative;
  display: inline-block;
  width: 120px;
  height: 46px;
}

.switch input { 
  opacity: 0;
  width: 0;
  height: 0;
}

.slider {
  position: absolute;
  cursor: pointer;
  top: 0;
  left: 0;
  right: 0;
  bottom: 0;
  background-color: #ccc;
  -webkit-transition: .4s;
  transition: .4s;
}

.slider:before {
  position: absolute;
  content: " dhcp";
  height: 36px;
  width: 52px;
  left: 4px;
  bottom: 4px;
  background-color: white;
  -webkit-transition: .4s;
  transition: .4s;
}

input:checked + .slider {
  background-color: #2196F3;
}

input:focus + .slider {
  box-shadow: 0 0 1px #2196F3;
}

input:checked + .slider:before {
  -webkit-transform: translateX(52px);
  -ms-transform: translateX(52px);
  transform: translateX(52px);
  content: "static";
}
.restart {
font-size:16px;
color:#2db300; 
}
#myDiv, #myDav {
 border: 1px solid black
}
</style>
<script type='text/javascript'>
    
function test() {
//alert("test");
if(document.getElementById("sw").checked){
document.getElementById('myDiv').style.display='none';
document.getElementById('myDav').style=display='block';
} else {
document.getElementById('myDiv').style.display='block';
document.getElementById('myDav').style.display='none';
}

}

function zendStatic() {
if(!confirm("are you sure to save this data?")){
   alert("setup static ip canceled"); 
   return false;
   }

spinner();
checkReaction();
document.getElementById('staticForm').submit();
}

function sendDhcp() {
if(!confirm("are you sure to save this data?")){
   alert("dhcp setup canceled"); 
   return false;
   }
  spinner();
  checkReaction();
  document.getElementById('dhcpForm').submit();
}

function helpfunctie() {
document.getElementById("help").style.display = "block";
}
function sl() {  
document.getElementById("help").style.display = "none";
}

function spinner(){
document.getElementById('loaderdiv').style.visibility = 'visible';
//setTimeout( function() { hideLoader(); }, 1000);
}

function checkReaction() {
//spinner();
   if(window.frames[0].document.body.innerHTML == "") {
     window.setTimeout(checkReaction, 500);
   } else {
     hideLoader();
     showReboot(); 
   }
}


function showReboot() {
//document.getElementById('myDiv').style.display="none";
//document.getElementById('myDav').style.display="none";
document.getElementById('formdiv').style.display="none";
document.getElementById('testveld').innerHTML="<br><br><br><span class='restart'>The new wifi settings are saved.<br>Click the button to effectuate the settings.<br>This page will no longer be responsive if you configured a new ip!<br><br><button class='knop' onclick='restart()'>RESTART</button><br><br></span>";
}

function hideLoader() {
document.getElementById('loaderdiv').style.visibility = 'hidden';
}

function restart() {
//first wipe the frame
//window.frames[0].document.body.innerHTML = "";
spinner();
document.getElementById('restartform').submit();
setTimeout(function(){
   window.location.reload();
}, 5000);
}
</script>
  
</head>
<body onload='test()'>
<!-- the plan is to have a invisible div with the spinner. -->
<div id='loaderdiv'><div class='loader'></div></div>

<center>
<div id='msect'><center>
<div id='help'>
  <span class='close' onclick='sl();'>&times;</span><h3>IP CONFIG HELP V4.0</h3>
  <b>DHCP</b><br>Your router handsout the ip address.
  <br><br><b>STATIC</b><br>
  The ip address is defined by you. Usually this is not needed<br>because the router always handsout the same ip address to a certain device.
   <br><br>
<b>DHCP / STATIC</b><br>
If you click the button, the properties of the wifi connection are changed. This only becomes effective when you click the restart button (or reboot).
<br><br>
<b>RESTART</b><br>
If you clicked 'restart', the network connection is restarted. When the connection properties were changed, this page is likely not reponsive anymore so you have to browse to the new IP.<br>
You can find your device by typing <strong>http://rpi-ecu.local </strong> in your browser.

</div>
<div id='msect'><div id='menu'>>
<a id='fleft' href='#' onclick='helpfunctie()'>help</a></li>
<a href="menu.html" class='close'>&times;</a>
</div></div>
<br>
<div id='msect'><center>
<kop>  SETUP STATIC / DHCP IP</KOP>
<div class='divstijl'>
<center>
<div id='formdiv'>
<br>
<?php
$file = fopen("/var/www/ecu_data/wifistatus.txt","r");
$status = rtrim(fgets($file));
fclose($file);
if ($status == 'static') {
$chk = "checked";
} else {
$chk = "";
}

echo "<table><tr>";
echo "<td>DHCP<td><label class='switch' onchange='test()'>";
echo "<input type='checkbox' id='sw'" . $chk . "><span class='slider'></span>";
?>
</label><td>STATIC</td></tr></table><br>

<div id='myDiv' style='display:block'>
<form method='post' id='dhcpForm' action='/cgi-bin/ecu/wifi/wifi_dhcp.pl' target='hiddenFrame'><h4>setup dhcp</h4></form><button class='knop' onclick='sendDhcp()'>DHCP</button> 
</div>

<div id='myDav' style='display:none'>
<h4>setup static ip address</h4><form method='post' id='staticForm' target='hiddenFrame' action='/cgi-bin/ecu/wifi/wifi_static.pl'>
<table><tr><td>ip router <td>
<?php 
$file = fopen("/var/www/ecu_data/myipnr.txt","r");
$localip = rtrim(fgets($file));
fclose($file);
$gateway = substr($localip, 0, strrpos($localip, "."));
$gateway .= ".1";
echo"<input name='gw' id='gw' required pattern='^(([0-9]|[1-9][0-9]|1[0-9]{2}|2[0-4][0-9]|25[0-5])\.){3}([0-9]|[1-9][0-9]|1[0-9]{2}|2[0-4][0-9]|25[0-5])$' class='inp1' title='192.168.x.x (not over 254)' value='" . $gateway . "'>";

echo"<tr><td>static ip<td><input name='ip' id='ip' required pattern='^(([0-9]|[1-9][0-9]|1[0-9]{2}|2[0-4][0-9]|25[0-5])\.){3}([0-9]|[1-9][0-9]|1[0-9]{2}|2[0-4][0-9]|25[0-5])$' class='inp1' title='192.168.x.x (not over 254)'>";

echo"<tr><td>dns<td><input name='nm' id='nm' required pattern='^(([0-9]|[1-9][0-9]|1[0-9]{2}|2[0-4][0-9]|25[0-5])\.){3}([0-9]|[1-9][0-9]|1[0-9]{2}|2[0-4][0-9]|25[0-5])$' class='inp1' title='192.168.x.x (not over 255)' value='" . $gateway . "'></table><br></form><button class='knop' onclick='zendStatic()'>STATIC</button>";
?>
</div>
</div>
<div id='testveld'></div>
<br>


<?php
$file = fopen("/var/www/ecu_data/debugstatus.txt","r");
$status = rtrim(fgets($file));
fclose($file);
if ($status == 'on') {
   echo "<iframe name='hiddenFrame' height='180'></iframe>";
} else {
   echo"<iframe name='hiddenFrame' height='0' hidden></iframe>";
}
?>
<form id='restartform' action='/cgi-bin/ecu/wifi/wifi_restart.pl' hidden target='hiddenFrame'></form>
 </body>
 </html> 

