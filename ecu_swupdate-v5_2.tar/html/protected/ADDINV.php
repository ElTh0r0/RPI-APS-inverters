<!DOCTYPE html><html><head><meta charset='utf-8'>
<title>RPI-ECU</title>
<meta name="viewport" content="width=device-width, initial-scale=1">
<link rel="icon" type="image/x-icon" href="/favicon.ico" />
<link rel="stylesheet" type="text/css" href="/STYLESHEET.css">
<link rel="stylesheet" type="text/css" href="/STYLESHEET_TEST.css">
<script type='text/javascript'>

function helpfunctie() {
document.getElementById("help").style.display = "block";
}
function sl() {  
document.getElementById("help").style.display = "none";
}
function showSubmit() {
document.getElementById("sub").style.display = "block";
}
function submitFunction(a) {
if(!confirm("are you sure to add this inverter?")){
return false;
}
spinner();

document.getElementById('formulier').submit();
setTimeout(function(){window.location.href='INVERTERS.php';}, 6000 ); 
}
</script>

</head>
<body>
<div id='loaderdiv'><div class='loader'></div></div>
<div id='msect'>
  <div id="help">
  <span class='close' onclick='sl()'>&times;</span><h3>INVERTER SETTINGS HELP</h3>
  <b>you can add max 9 inverters.</b><br><br>
  <b>inverter nr</b><br>
  pick one of the availabe inverter nrs<br><br>  
  <b>name</b><br>
  Enter a meaningfull name or the location of the inverter.
  <br><br><b>inverter serialnr:</b><br>
  You can find the serialnr stickered on the inverter.
  <br><br><b>panels:</b><br>
  Check which solar panels are connected.
  <br><br>
  </div>
</div>


<div id='msect'>
<div id='menu'>
<a href="INVERTERS.php" class='close'>&times;</a>
<a id='fleft' href='#' onclick='helpfunctie()'>help</a>
<a id='sub' href='#' onclick='submitFunction("menu.html")'>save</a>
</div>
</div>
<div id='msect'>
<kop>add a new inverter</kop>
</div>

<div id='msect'>

<center><div class='divstijl' style='height:64vh;'>
<!--
***************************************************** 
*            START OF THE FORM                      *
*****************************************************
-->
<form id='formulier' method='get' action='/cgi-bin/ecu/inverterSave.pl' oninput='showSubmit()' target='hiddenFrame'>

<input name='new' value='1' style='display:none;'></input>
<input name='ivid' value='unpaired' style='display:none;'></input>

<table style='background-color: #ffb3ff; padding:10px;'><tr><td style='width:90px;'><h4>INVERTER</h4><td style='width:90px;'>
<select name='ivnr' class='sb2'>
<?php
for($x = 0; $x < 10; $x++){
# pick the free inverternumbers
$filename="/var/www/ecu_data/inverters/invProperties" . $x;
if(!file_exists($filename)) {
echo "<option value='" . $x . "'>" . $x . "</option>";
} 

}

echo"input class='inp1' name='ivnr' value='" . $invNR . "' >";

?>
</tr><br>

<tr><td style='width:100px;'>SERIALNR<td><input class='inp4' id='ivser' name='ivser' minlength='12' maxlength='12' required></input></tr>

<tr><td>TYPE<td><select id='invt' name='invt' class='sb2' onchange='myFunction()'>

<option value='0' >YC600</option>
<option value='2' >DS3</option>
<option value='1' >QS1</option>
</select></tr>

<tr><td>NAME<td><input class='inp4' id='in' name='in' maxlength='12'></input>

<tr><td>DOM. IDX<td><input class='inp2' name='mqidx' size='4' length='4'></td></tr>

<tr><td>THROT CAL<td><input class='inp2' name='invtc' type='number' min='-15' max='15' value='0'</td></tr>

<tr><td>PANELS:<td style='width: 230px;'>

1&nbsp;<input type='checkbox' name='pan1'>

2&nbsp;<input type='checkbox' name='pan2'>

<span id='invspan' style='display:none'>
 
3&nbsp;<input type='checkbox' name='pan3'" . $check2 . ">

4&nbsp;<input type='checkbox' name='pan4'" . $check3 . ">

</span>


</tr></td></table></form>

  </div>
</div>
<div id='msect'>
  
  <br>

<iframe name='hiddenFrame' width='420' height='100' hidden></iframe>  
</div>

<script type="text/javascript">
function spinner(){
document.getElementById('loaderdiv').style.visibility = 'visible';
}

function showFunction() {
  //alert("showFunction");
  document.getElementById("invspan").style.display = "inline";
}
function hideFunction() {
  //alert("showFunction");
  document.getElementById("invspan").style.display = "none";
}
function myFunction(){
 if(document.getElementById("invt").value != 1 ) { 
    hideFunction();
 } else {
   showFunction();
 }
}

</script>
</body></html>