<!DOCTYPE html><html><head><meta charset='utf-8'>
<title>RPI-ECU</title>
<meta name="viewport" content="width=device-width, initial-scale=1">
<link rel="icon" type="image/x-icon" href="/favicon.ico" />
<link rel="stylesheet" type="text/css" href="/STYLESHEET.css">
<link rel="stylesheet" type="text/css" href="/STYLESHEET2.css">

<script type='text/javascript'>

function helpfunctie() {
document.getElementById("help").style.display = "block";
}
function sl() {  
document.getElementById("help").style.display = "none";
}
function showSubmit() {
document.getElementById("sub").style.display = "block";
}

function submitFunction(a) {
if(!confirm("are you sure to save inverter " + a + "?")){
return false;
}
//document.getElementById("bo").innerHTML="<br>wait...<br>processing<br>your<br>request"; 
//document.getElementById("bo").style.display="block"; 
spinner();
checkReaction();

document.getElementById('formulier').submit();
setTimeout(function(){window.location.href='INVERTERS.php';}, 5000 ); 

}
function delFunctie(a) {
if(!confirm("are you sure to delete inverter " + a + " ??")){
return false;
}
document.getElementById('invdel').value=a;
spinner();
//checkReaction();

document.getElementById('delform').submit();
setTimeout(function(){window.location.href='INVERTERS.php';}, 5000 ); 
}
</script>
</head>
<body>
<!-- the plan is to have a invisible div with the spinner. -->
<div id='loaderdiv'><div class='loader'></div></div>

<center>

<div id='msect'><center>

  <div id="help">
  <span class='close' onclick='sl();'>&times;</span><h3>INVERTER SETTINGS HELP</h3>
  <b>you can add max 9 inverters.</b><br><br>
  <b>name</b><br>
  Enter a meaningfull name or the position of the inverter.
  <br><br><b>inverter serialnr:</b><br>
  You can find the serialnr stickered on the inverter.
  <br><br><b>panels:</b><br>
  Check which panels are connected.
  <br><br><b>Dom idx:</b><br>
  Identification that is sent in mqtt messages to 'Domoticz'.

  <br><br><b>pair:</b><br>
  link your inverter to this ECU in order to make the zigbee communication possible.<br>
  When paired you will see the obtained inverter ID in the status field.
  You can find more information in the log or information page. 
  <br><br>
  </div>
  </div>
<div id='msect'>
<div id='menu'>
<a href="menu.html" class='close'>&times;</a>


<?php

$inverterCount;
if(file_exists("/var/www/ecu_data/inverterCount.txt"))
{
$file = fopen("/var/www/ecu_data/inverterCount.txt","r");
$Count = rtrim(fgets($file));
$inverterCount=(int)$Count;
fclose($file);
} 
else 
{
$inverterCount=0;
echo "<a id='fleft' href='ADDINV.php'>add</a>";
goto error1;
}

for ($x = 0; $x < 10; $x++) {
# if there is a file we display the link 
$filename="/var/www/ecu_data/inverters/invProperties" . $x;

if(file_exists($filename)) { 
echo "<a id='fleft' href='#' onclick='invKeuze(" . $x . ")'>inv " . $x . "</a>";
}
}
if($inverterCount < 9) {
echo "<a id='fleft' href='ADDINV.php'>add</a>";
}
echo "</div></div><div id='msect'>";

// we read the file for the value of invKeuze
$file="/ramdisk/invChoice.txt";
if(file_exists($file)){
$inv = file_get_contents($file);
} else {
$inv = 0;
}
$invnr = intval($inv);

echo "<div class='divstijl' style='height:64vh;'><center>";
/*
# *****************************************************
# *            START OF THE FORM                      *
# *****************************************************
*/
echo "<form id='formulier' method='get' action='/cgi-bin/ecu/inverterSave.pl' oninput='showSubmit()' target='hiddenFrame'>";
  
echo "<table><tr><td style='width:90px;'>";
// if we deleted inv 0, invChoice becomes the first available

if($inverterCount == 0) {goto error1;}

//$filename="/var/www/ecu_data/inverters/invProperties" . $invnr;
$filename="/var/www/ecu_data/inverters/invProperties$invnr";
//echo "<h2>filename = " . $invnr;
$json = file_get_contents($filename);
//echo "<h2>json= " . $json . "</h2>";
$arr = json_decode($json, true);
$invID=$arr["id"];
$invSerial=$arr["serial"];
$invType=$arr["type"];
$invName=$arr["name"];
$invIdx=$arr["idx"];
$throtCal=$arr["cal"];
$p0=$arr["panels"][0];
$p1=$arr["panels"][1];
$p2=$arr["panels"][2];
$p3=$arr["panels"][3];

echo"<h4>INVERTER</h4><td style='width:90px;'><input class='inp1' name='ivnr' value='" . $invnr . "' readonly>";

echo"<td style='width:50px;'><h4>STATUS:</h4><td>";
if($invID == "") {$invID="unpaired";}
echo"<input style='width:100px;' name='ivid' class='inp3' value='" . $invID . "' readonly></tr></table><br>";

echo"<table style='background-color: lightgreen; padding:10px;'>";
    
echo"<tr><td class='cap' style='width:100px;'>SERIALNR<td><input class='inp4' id='iv' name='ivser' minlength='12' maxlength='12' required value='" . $invSerial . "'></input></tr>";

echo"<tr><td class='cap'>TYPE<td><select id='invt' name='invt' class='sb2' onchange='myFunction()'>";
$selyc='';
$selds='';
$selqs='';

if($invType == '0') {
$selyc = "selected";
} elseif ($invType == '1') {
$selqs = "selected";
} else {
$selds = "selected";
}

echo"<option value='0' " . $selyc . ">YC600</option>";
echo"<option value='2' " . $selds . ">DS3</option>";
echo"<option value='1' " . $selqs . ">QS1</option>";
echo"</select></tr>";

echo "<tr><td class='cap' >NAME<td class='cap' ><input class='inp4' id='in' name='in' maxlength='18' value='" . $invName . "'></input>";

echo"<tr><td class='cap' >DOM. IDX<td class='cap' ><input class='inp2' name='mqidx' value='". $invIdx . "' size='4' length='4'></td></tr>";

echo"<tr><td class='cap' >THROT CAL<td class='cap' ><input class='inp2' name='invtc' type='number' min='-15' max='15' step='1' value='". $throtCal . "' size='4' length='4'></td></tr>";


$check0='';
$check1='';
$check2='';
$check3='';
echo"<tr><td class='cap' >PANELS:<td style='width: 230px;'>";

if($p0 == "1") {$check0 = "checked";}
echo"1&nbsp;<input type='checkbox' name='pan1'" . $check0 . ">";

if($p1 == "1") {$check1 = "checked";}
echo"2&nbsp;<input type='checkbox' name='pan2'" . $check1 . ">";

echo"<span id='invspan' style='display:";
if($invType == '1') {echo"inline;'>";} else {echo"none;'>";} 

if($p2 == "1") {$check2 = "checked";}
echo"3&nbsp;<input type='checkbox' name='pan3'" . $check2 . ">";

if($p3 == "1") {$check3 = "checked";}

echo"4&nbsp;<input type='checkbox' name='pan4'" . $check3 . ">";
echo "</span>";



echo "</tr></td></table></form><br></div></div>";

echo "<div id='msect'><center>";
echo "<div id='menu'>";
echo "<a id='fleft' href='#' onclick='delFunctie(" . $invnr . ")'>delete</a>";


echo"<a id='fleft' href='PAIRING.php'>pair</a>";
echo"<a id='fleft' href='#' onclick='helpfunctie()'>help</a>";

echo"<div id='sub' class='submit' onclick='submitFunction($invnr)'>save</a>";

goto phpend;
error1:
echo"<h1>currently no inverter exists, click add</h4>"; 
echo"</body></html>"; 

phpend:
?>



<br>
<form id='delform' action='/cgi-bin/ecu/inverterDel.pl' style='display:none' target='hiddenFrame'>
<input type='hidden' name='ivnr' id='invdel'></form>
</div>

<script type="text/javascript">

function spinner(){
document.getElementById('loaderdiv').style.visibility = 'visible';
}

function showFunction() {
  //alert("showFunction");
  document.getElementById("invspan").style.display = "inline";
}
function hideFunction() {
  //alert("showFunction");
  document.getElementById("invspan").style.display = "none";
}
function myFunction(){
 if(document.getElementById("invt").value != '1' ) { 
    hideFunction();
 } else {
   showFunction();
 }
}
function invKeuze(a) {
document.getElementById("ivnr").value = a;
spinner();
checkReaction();
document.getElementById("invKeuze").submit();
}

function checkReaction() {
if(window.frames[0].document.body.innerHTML == "") {
   window.setTimeout(checkReaction, 500);
   } else {
   hideLoader();
   }
}

function hideLoader() {
document.getElementById('loaderdiv').style.visibility = 'hidden';
location.reload();
}
</script>
<iframe id='hf' name='hiddenFrame' width='420' height='100' hidden></iframe>

<form id='invKeuze' action='/cgi-bin/ecu/invkeuzeSave.pl' target='hiddenFrame'>
<input name='ivnr' id='ivnr' style='visibility:hidden'>
</div>
  
</body></html>
