<?php
$debugfile = "/var/www/ecu_data/debugstatus.txt";
$debugValue = trim(file_get_contents($debugfile));
$debug = ($debugValue !== "0");
?>

<!DOCTYPE html><html><head><meta charset='utf-8'>

<title>ESP-ECU</title>
<meta name="viewport" content="width=device-width, initial-scale=1">
<META HTTP-EQUIV="Content-Disposition" CONTENT="inline" />
<link rel="icon" type="image/x-icon" href="/favicon.ico" />
<link rel="stylesheet" type="text/css" href="/STYLESHEET.css">
<link rel="stylesheet" type="text/css" href="/STYLESHEET2.css">

<script type='text/javascript'>
var debug = <?php echo $debug ? 'true' : 'false'; ?>;
//console.log("debug = " + debug);
function init() {
if(debug) {
document.getElementById('debugFr').style.display = 'block';
  }
}
function helpfunctie() {
document.getElementById("help").style.display = "block";
}
function sl() {  
document.getElementById("help").style.display = "none";
}

function hideLoader() {
document.getElementById('loaderdiv').style.visibility = 'hidden';
}

function refreshfunction() {
location.reload();
}


function restsubmit() {
    window.frames[0].document.body.innerHTML = ""; 
    spinner();
    checkulReaction();   
    document.getElementById("uploadForm").submit();
    if(!debug) {
    window.setTimeout('window.location.reload()', 4000);
    } 
}

function dummy(){
var q = 10;
 // do nothing
}
function readyfunction(){
window.location.href = "menu.html";
}
</script>
<style>
.inputfile {
	width: 0.1px;
	height: 0.1px;
	opacity: 0;
	overflow: hidden;
	position: absolute;
	z-index: -1;
}
.lbl {
border:3px solid black;
font-size:20px;
padding: 4px;
color: blue;
background-color:lightgrey;
border-radius: 8px;}
label:hover {
    background-color:red;
}
</style>

</head>
<body onload='init()'>
<!-- the plan is to have a invisible div with the spinner. -->
<div id='loaderdiv'><div class='loader'></div></div>

<center>
 <div id='msect'><center>

  <div id="help">
  <span class='close' onclick='sl();'>&times;</span><h3>PHOTO UPLOAD HELP</h3>
  <b>PURPOSE:</b><br>
  With this tool you can upload a photo to your ECU.<br>You can have only one photo at the same time, when you upload another photo, the existing one will be overwritten.
<br><br><b>FILENAME:</b><br>
The upoad accepts only photo's with the name ecu_photo.jpg. <br><br>
<b>FILESIZE:</b>
<br>The size of the photo is limited to 140 kB (140.000 bytes).
<br>If your photo is too large, try to open it with photo software like 'paint' and export it with a size of hight 500pixels. This is usually enough.<br><br>
<b>CHECK:</b>
<br>You can check the results of the upload in the frame below. In case of an error you can try again. <br>If you do not see the expected photo, please delete your browser cache. 
  <br><br>
  </div>

    <div id='bo'></div>
<div id='menu'>
<a id='fleft' href='#' onclick='helpfunctie()'>help</a>
<a id='fleft' href='/photo.html'>view</a>
<a id='fleft' href='#' onclick='deletefunction()'>delete</a>
<a href="menu.html" class='close'>&times;</a>
</div></div>

   <h2>ECU PHOTO UPLOAD</h2>
<div class='divstijl'><center>

<div id="okdiv" style='display:none;position: relative;
  top: 30px;' >
The installation script has run, check the results below and click OK<br>
<br>
<button type='button' class= 'butt' onclick='readyfunction()'>OK</button>
</div>

<div id='formdiv' style='border:1px solid; display:block;'>
  <br>
  <form id="uploadForm" method="post" enctype="multipart/form-data" action="upload_photo.php" target='hiddenFrame'>
<label id='laBel' for='fileToUpload' class='lbl'>choose a file</label>
<input type='file' name="fileToUpload" id="fileToUpload" accept ='.jpg' required='required' oninput='showButton()' class='inputfile'>
  </form>
<br><br>
</div>

<br><br><br>

<h3><div id='show'></div><h3>


  <div id='subButton' style='display:none'><button class= 'butt' type='button' name='haha' onclick='restsubmit()'>upload</button><br><br></div>


<form id='delform' action='/cgi-bin/ecu/photoDel.pl' style='display:none' target='hiddenFrame'>
</form>

<br>

<iframe id='debugFr' name='hiddenFrame' height='200' hidden></iframe>  

</div>

<script>
function spinner(){
document.getElementById('loaderdiv').style.visibility = 'visible';
}

function checkulReaction() {
//spinner();
if(window.frames[0].document.body.innerHTML == "") {
   window.setTimeout(checkulReaction, 500);
   } else {
   hideLoader();
var reaction = window.frames[0].document.body.innerHTML; 
console.log(reaction);
if( reaction.indexOf("Error") == -1){
document.getElementById("installdiv").style.display="block";
document.getElementById("subButton").style.display="none";
document.getElementById("formdiv").style.display="none";

   } else {
alert("An error occurred, please try again");
   refreshfunction();
   }
  }
}

function showButton() {
var hihi = document.getElementById("fileToUpload").value;
var hoho = hihi.replace(/^.*\\/, "");
//alert("value = " + hoho);
document.getElementById("show").innerHTML=hoho;

//var hoho=document.getElementById("fileToUpload").value;
//alert("showbutton " + hoho);
if(hoho == "") {
alert("you didn't choose a file, try again");
refreshfunction();
} else {
document.getElementById("subButton").style.display="block";
}
}

function deletefunction() {
if(!confirm("are you sure to delete the existing photo?")){
return false;
}
window.frames[0].document.body.innerHTML = ""; 
spinner();
checkulReaction();   
document.getElementById("delform").submit();
window.setTimeout('window.location.reload()', 3000);
}
</script>


</body></html>