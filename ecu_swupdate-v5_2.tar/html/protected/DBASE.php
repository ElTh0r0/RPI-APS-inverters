<!DOCTYPE html><html><head><meta charset='utf-8'>
<title>ESP-ECU</title>
<meta name="viewport" content="width=device-width, initial-scale=1">
<link rel="icon" type="image/x-icon" href="/favicon.ico" />
<link rel="stylesheet" type="text/css" href="/STYLESHEET.css">
<link rel="stylesheet" type="text/css" href="/STYLESHEET2.css">

<script type='text/javascript'>

function helpfunctie() {
document.getElementById("help").style.display = "block";
}
function sl() {  
document.getElementById("help").style.display = "none";
}

function hideLoader() {
document.getElementById('loaderdiv').style.visibility = 'hidden';
}

function refreshfunction() {
location.reload();
}

</script>
</head>
<body>
<!-- the plan is to have a invisible div with the spinner. -->
<div id='loaderdiv'><div class='loader'></div></div>

<div id='msect'><center>
  <div id="help">
  <span class='close' onclick='sl();'>&times;</span><h3>DATABASE MANAGEMENT HELP</h3>
To store measured values from inverters, there are two databases, named: <br>
 <strong>invData</strong> (stores the polled power and energy per inverter)<br>
 structure: measurement inv 0 to 8,  fields p and e <br>
<strong>invEnergy</strong> (stores daily total energy per inverter).<br>
structure: measurement inv0 to inv8,  field e
<br><br>
 
<b>usage</b><br>
- choose an inverternr in the 1st input.<br>
- choose a date in the 2nd input.
- choose an action in the 3th input.
<br><br>
example 1 : if you select 0 in 1st select and 2022-03-01 in the 2nd and choose<br>
'query from invData' then you can see data from 'invData' (the last 20 below the given date).
<br><br>
example 2 : if you select 0 in 1st select, and choose<br>
'wipe all values in invData' then all values for inverter 0
will be erased.<br>

<br><br>
If you remove an inverter and you are sure that you don't need its data anymore, you should wipe this data to free space on your sd.

<br><br>In the screen below you can follow the process.<br><br>
</div>

<div id="menu">
<a id='fleft' href='#' onclick='helpfunctie()'>help</a>
<a id='fleft' href='SETENERGY.php'>edit</a>
<a id='fleft' href='DBBACKUP.php'>backup</a>
<a id='fleft' href='DBRESTORE.php'>restore</a>
<a href="menu.html" class='close'>&times;</a>
</div>

<kop>RPI-ECU DATABASE MANAGEMENT</kop>

<div class='divstijl' ><center>

<div id='formDiv' style='display:block'>

<form id='invKeuze' action='invKeuze()' target='hiddenFrame'>
<table><tr><td>inverternr<td>
<select name='ivnr' id='ivnr' class='sb3' onchange='invKeuze()'>
<option selected readonly>CHOOSE INVERTER</option>

<?php
// we read the file qinvChoice.txt for inv nr and date
$file="/var/www/ecu_data/qinvChoice.txt";
if(file_exists($file)){
$fp = fopen('/var/www/ecu_data/qinvChoice.txt', 'r');

$dat = fgets($fp);
$invnr = (int)fgetc($fp);
$datum = new DateTime("$dat");
$datum = $datum->format("Y-m-d");
fclose($fp);
} else {
$datum = date('Y-m-d');
$invnr = 0;
$klik = 1;
}
//$invnr=(int)$Count;
for($x = 0; $x < 10; $x++){
# pick the available inverters
$sel = "";

$filename="/var/www/ecu_data/inverters/invProperties" . $x;
  if(file_exists($filename)) {
    $jsan = file_get_contents($filename);
    $orr = json_decode($jsan, true);
    $name = $orr["name"];
    
    if($invnr == $x) {$sel = "selected";}   
    echo "<option " . $sel . " value='" . $x . "'>" . $x ." " . $name . "</option>";
   } 
}

echo "</select><tr><td>date<td>";
echo"<input type='date' id='dat' name='dt' value='" . $datum . "'></input>";
?>
</form>
<tr><td>action<td>
<select id='sel' class='sb3' name"actionSelect" onchange="actionFunction()">
<option selected readonly>CHOOSE ACTION</option>
<option value='5'>healtcheck influx</option>
<option value='2'>query * from invData limit 1000</option>
<option value='3'>query * from invEnergy</option>
<option value='4'>query this date from invData</option>
<option value='0'>wipe values of invx in invData</option>
<option value='1'>wipe values of invx in invEnergy</option>

</select></table></div>

<iframe id='of' name='outputFrame' height='320px' style='margin-bottom:10px;'></iframe>

</div>

<br></div></div>
<form id='delInvdata' action='/cgi-bin/ecu/dbWipe.pl' style='display:none' target='outputFrame'>
<input name="db" value='invData'></input>'>
<input id='welkeDatawipe' name='ivnr'>
<input id="whichQuery" name="what" value="0"></input>
</form>

<form id='delInvenergy' action='/cgi-bin/ecu/dbWipe.pl' style='display:none' target='outputFrame'>
<input name="db" value='invEnergy'></input>'>
<input id="welkeEnergywipe" name='ivnr'></input>
<input id="whichQuery" name="what" value="1"></input>
</form>

<!-- the queries -->
<form id='qInvdata' action='/cgi-bin/ecu/dbQuery.pl' style='display:none' target='outputFrame'>
<input id="datD" name="datum"</input>
<input id='welkeInv2' name='ivnr'></input>
<input id="whichQuery2" name="what" value="2"></input>
</form>

<form id='qInvenergy' action='/cgi-bin/ecu/dbQuery.pl' style='display:none' target='outputFrame'>
<input id="datE" name="datum"</input>
<input id="welkeInv3" name="ivnr"></input>
<input id="whichQuery3" name="what" value="3"></input>
</form>

<form id='qDate' action='/cgi-bin/ecu/dbQuery.pl' style='display:none' target='outputFrame'>
<input id="datF" name="datum"</input>
<input id="welkeInv4" name="ivnr"></input>
<input id="whichQuery4" name="what"></input>
</form>

<form id='health' action='/cgi-bin/ecu/healthInflux.pl' style='display:none' target='outputFrame'>
</form>

</body>

<script>
var iKeuze;
var iDatum;

function spinner(){
document.getElementById('loaderdiv').style.visibility = 'visible';
}

function actionFunction() 
{
// first read the values from the form inputs before they disappear
   b=document.getElementById("sel").value;
   iKeuze = document.getElementById("ivnr").value;
   iDatum = document.getElementById("dat").value;

// we change the innerHTML of the form, the inputs are replaced
// with the refreshbutton 

document.getElementById("formDiv").innerHTML="<button class='butt' id='focusbut' onclick='refreshfunction()'>send another command</button><br>";   


   document.getElementById("focusbut").focus();
   
   if(b==0)
   {
      
         if(!confirm("are you sure to wipe all data from measurement 'inv" + iKeuze + "' in database 'invData' ?"))
         {
          location.reload();
          } else {
          spinner();
          checkReaction();
          document.getElementById("welkeDatawipe").value=iKeuze;   
          document.getElementById("delInvdata").submit();
          } 
     
   }
   if(b==1) // delete from invEnergy
   {
         if(!confirm("are you sure to wipe all data from measurement 'inv"+ iKeuze + "' in database 'invEnergy' ?"))
         {
          location.reload();
          } else {
          spinner();
          checkReaction();
          document.getElementById("welkeEnergywipe").value=iKeuze;   
          document.getElementById("delInvenergy").submit();
          } 
     

  }

if(b==2) // invData query 
   {
      spinner();
      checkReaction();
      document.getElementById("welkeInv2").value=iKeuze;
      document.getElementById("datD").value=iDatum;
      document.getElementById("whichQuery2").value=2; 
      document.getElementById("qInvdata").submit();
    } 
   
if(b==3) // invEnergy query 
   {
      spinner();
      checkReaction();
      document.getElementById("welkeInv3").value=iKeuze;
      document.getElementById("datE").value=iDatum;
      document.getElementById("whichQuery3").value=3;
      document.getElementById("qInvenergy").submit();
    } 

if(b==4) // invData query only this date 
   {
      spinner();
      checkReaction();
      document.getElementById("welkeInv4").value=iKeuze;
      document.getElementById("datF").value=iDatum;
      document.getElementById("whichQuery4").value=4; 
      document.getElementById("qDate").submit();
    } 

if(b==5) // healtcheck 
   {
          spinner();
          checkReaction();
          document.getElementById("health").submit();
        
    } 
}

var isDigit = (function() {
    var re = /^\d$/;
    return function(c) {
        return re.test(c);
    }
}());

function hasLowerCase(str) {
    return (/[a-z]/.test(str));
}

function checkReaction() {
//spinner();
if(window.frames[0].document.body.innerHTML == "") {
   window.setTimeout(checkReaction, 500);
   } else {
   hideLoader();
}
}

</script>
</html>