<!DOCTYPE html><html><head><meta charset='utf-8'>

</head>
<?php
//first determine what the query is and extract the inv nr
$req=$_SERVER['QUERY_STRING'];
$errornr = 0;
$debug    = isset($_GET['debug']) && $_GET['debug'] === "true";
$inverter = isset($_GET['inv']) ? intval($_GET['inv']) : null;
$throtval = isset($_GET['throttle']) ? intval($_GET['throttle']) : null;        

// Validate inverter number
if ($inverter < 0 || $inverter > 9) {
    echo "bad inverter nr: " . htmlspecialchars($inverter) . "<br>";
    goto end;
}

// Validate throttle
if ($throtval === null || $throtval < 20 || $throtval > 900) {
    echo "bad throttle value: " . htmlspecialchars($throtval) . "<br>";
    goto end;
}

// have a valid inverternr
// now we check if this inverter has a properties file
// so we know the it exists
$dataFile = "/var/www/ecu_data/inverters/invProperties" . $inverter;
	//echo "dataFile = " . $dataFile ."<br>\n";
if(!file_exists($dataFile)) {
 
echo "inverter " . $inverter . " does not exist. <br>\n";	
goto end;
}

// if we are here the arguments are valid
// so we can call throttleSave.pl with the arguments

// Escape arguments to prevent shell injection
$inverter_esc  = escapeshellarg($inverter);
$throtval_esc = escapeshellarg($throtval);

$perl_script = "/usr/lib/cgi-bin/ecu/throttleSave.pl";

$cmd = "REQUEST_METHOD=GET QUERY_STRING='pMax=$throtval&inv=$inverter' perl " . escapeshellarg($perl_script);

$output = [];
$return_var = 0;

exec($cmd, $output, $return_var);

// Show script output conditional
if($debug) 
{
   foreach ($output as $line) {
    echo htmlspecialchars($line) . "<br>";
   }
}

if ($return_var === 0) {
    echo "Throttle set successfully (inv=$inverter, throttle=$throtval)<br>";
} else {
    echo "Error: throttle script failed (code $return_var)<br>";
}

goto end;
error:
echo "<br>bad request " . $req . ", skipped\n";

end:

?>
