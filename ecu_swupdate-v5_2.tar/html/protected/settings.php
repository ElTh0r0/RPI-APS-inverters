<!DOCTYPE html><html><head><meta charset='utf-8'>
<title>RPI-ECU</title>
<meta name="viewport" content="width=device-width, initial-scale=1">
<link rel="icon" type="image/x-icon" href="/favicon.ico" />
<link rel="stylesheet" type="text/css" href="/STYLESHEET.css">
<link rel="stylesheet" type="text/css" href="/STYLESHEET2.css">
<script type='text/javascript'>

function helpfunctie() {
document.getElementById("help").style.display = "block";
}
function sl() {  
document.getElementById("help").style.display = "none";
}
function showSubmit() {
document.getElementById("sub").style.display = "block";
}
function submitFunction(a) {
//document.getElementById("bo").innerHTML="<br>wait...<br>saving<br>your<br>settings"; 
//document.getElementById("bo").style.display="block"; 
spinner();
document.getElementById('formulier').submit();
setTimeout(function(){window.location.href='settings.php';}, 3000 ); 

function spinner(){
//alert("spinner");
document.getElementById('loaderdiv').style.visibility = 'visible';
}

}
</script>
<style>

select:nth-child(1) {
  width: 90px;
}

#subkut { 
float:left; 
display:none important!; 
}

</style>
</head>

<body>
<!-- the plan is to have an invisible div with the spinner. -->
<div id='loaderdiv'><div class='loader'></div></div>

<center>

<div id='msect'><center>
  <div id='help'>
  <span class='close' onclick='sl();'>&times;</span><h3>GENERAL SETTINGS HELP</h3>
  <b>ecu-id:</b><br>
  The id should have 12 characters e.g. D8A3011B9780
  
  <br><br><b>longitude / latitude</b><br>
  Needed to calculate the sunrise and sunset times.

  <br><br><b>poll offset</b><br>
  Minutes before sunset and after sunrise to stop/start polling. <br>When you enter -5, the polling starts 5 minutes before sunrise and ends 5 minutes after sunset.
    <br><br>
  </div></div>

<div id='msect'>
<div id='menu'>

<div id='sub' class='submit' onclick='submitFunction()'>save</div>
<a id='fleft' href='#' onclick='helpfunctie()'>help</a>
<a href="menu.html" class='close'>&times;</a>

</div>
</div>
<br>
<div id='msect'>
<H2>ECU GENERAL SETTINGS</h2>
</div>
<div id='msect'><center>
<div class='divstijl'>
  <form id='formulier' method='get' action="/cgi-bin/ecu/settingsSave.pl" oninput='showSubmit()' target='hiddenFrame'>
<?php

$filename = "/var/www/ecu_data/settings.json";
// if this file does'nt exist we put the defaults
if(!file_exists($filename)) {
$ecuid = 999999999999;
$longitude = "5.432";
$latitude = "50.543";	
$price= "0.20";
$cur = "&curren;";
$offset = "20";
} else {

$json = file_get_contents($filename);

$arr = json_decode($json, true);

$ecuid = $arr['id'];
$longitude = $arr['longitude'];
$latitude = $arr['latitude'];
$offset = $arr['offset'];
$price = $arr['price'];
//$cur = $arr['cur'];
//fclose($filename);
} 

$cur = "cu";
// we have to read the currency sign
$filename="/var/www/ecu_data/currency.txt";
  if(file_exists($filename)) {
    $fp = fopen($filename, 'r');
    $cur = trim(fgets($fp));    
    fclose($fp);
}
 
echo "<center><table>";
 echo "<tr><td style='width:30%;'>ecu id<td style='width:70%;'><input class='inp4' name='ecuid' value='" . $ecuid . "'minlength='12' maxlength='12' required title='12 characters'></input></td></tr>";
  
echo "<tr><td>longitude<td><input class='inp3' name='long' value='" . $longitude . "' size='4' ></td></tr>";

echo "<tr><td>latitude<td><input class='inp3' name='lati' value='" . $latitude . "' size='4' ></td></tr>";
$sel=$sel1=$sel2=$sel3=$sel4="";

echo "<tr><td>poll offset<td><input class='inp2' type='number' min='-10' max='30' name='offs' value='" . $offset . "' size='4' ></td></tr>";

echo "<tr><td>energy cost/KWh<td><input class='inp2' type='number' min='0' max='30' name='ep' value='" . $price . "' size='4' ></td></tr>";
if ($cur == "er") $sel1 = "selected";
if ($cur == "do") $sel2 = "selected";
if ($cur == "po") $sel3 = "selected";    
if ($cur == "cu") $sel4 = "selected";        
echo "<tr><td style='width:140px;'>currency<td><select name='cur' class='sb2'>";
echo "<option value='er' " . $sel1 . ">Euro</option>";
echo "<option value='do' " . $sel2 . ">Dollar</option>";
echo "<option value='po' " . $sel3 . ">GBPound</option>";
echo "<option value='cu' " . $sel4 . ">&curren;</option>";

echo "</select></td></tr>";
?>
</table></form>
  
</div>

<iframe name='hiddenFrame' width='420' height='100' hidden></iframe>

<br>

</div></body></html>