<!DOCTYPE html><html><head><meta charset='utf-8'>
<title>ESP-ECU</title>
<meta name="viewport" content="width=device-width, initial-scale=1">
<link rel="icon" type="image/x-icon" href="/favicon.ico" />
<link rel="stylesheet" type="text/css" href="/STYLESHEET.css">
<link rel="stylesheet" type="text/css" href="/STYLESHEET2.css">
<script type='text/javascript'>

function showSubmit() {
document.getElementById("sub").style.display = "block";
}

function submitFunction() {
if(!confirm("are you sure? And did you note down the new credentials?")){
   return false;
   }
spinner();
checkReaction();   
document.getElementById('pwform').submit();
 
}

function checkReaction() {
if(window.frames[0].document.body.innerHTML == "") {
   window.setTimeout(checkReaction, 500);
   } else {
   hideLoader();
   }
}

function hideLoader() {
document.getElementById('loaderdiv').style.visibility = 'hidden';
}

function spinner(){
document.getElementById('loaderdiv').style.visibility = 'visible';
}

</script>
</head>
<body>
<!-- the plan is to have a invisible div with the spinner. -->
<div id='loaderdiv'><div class='loader'></div></div>


<center>

<div id='msect'><center>
<div id='menu'>
<div id='sub' class='submit' onclick='submitFunction()'>save</div>
<a href="menu.html" class='close'>&times;</a>
</div>

<h2>EDIT PASSWORD</h2>

<div class='divstijl'>
<br><br>
Here you can change the credentials for this website.<br>
If you have this website open to the world it is very important<br>to have a strong password!!!
<form id='pwform' method='get' action='/cgi-bin/ecu/wifi/setPassword.pl' oninput='showSubmit()' target='outputFrame'>
<br><table style="border: 1px solid">
<th><th>your website credentials</th>
<tr><td>user<td><input class='inp7' type='text' name='user' required></tr>
<tr><td>passw<td><input class='inp7' type='text' name='pwd' required></tr>
</table><br>

</form>

<br>
<iframe name='outputFrame' width='90%' height='250' hidden></iframe>

<br></div></div>
<div id='msect'>

<br>

</body></html>