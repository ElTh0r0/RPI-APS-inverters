<?php
echo "\ngoing to upload the database backup file\r\n<br>";
$target_dir = "uploads/";
$target_file = $target_dir . basename($_FILES["fileToUpload"]["name"]);
print_r("\r\n target_file = " .$target_file) . "\r\n";
$uploadOk = 0;
$imageFileType = strtolower(pathinfo($target_file,PATHINFO_EXTENSION));
// Check if image file is a actual image or fake image
echo "<br>";
echo "<br> imageFileType= " . $imageFileType . "\r\n";

//the image size with one inverter after 10 days = 3kb
//in a year this means 36,5*3=109,5 per inverter
// for 10 inverters this is 1095 kb so we check that
// rounded to 1200kb
// Check file size


if($target_file != "") {

if ($_FILES["fileToUpload"]["size"] > 3000000) {
  echo "<br>Error, file is too large.\r\n";
  $uploadOk = 0;
  goto skip;
}
echo "<br>file to upload = " . $target_file;
//echo "result strstr" . strstr($target_file, "ecu_backup.tar")); 
if (strstr($target_file, "ecu_backup.tar")) { 
//if($target_file == "uploads/ecu_backup.tar") { 
    echo "<br><br>File name is correct.\r\n";
    $uploadOk = 1;
  } else {
    echo "\r\n Filename not correct should be ecu_backup.tar \r\n";
  
  $uploadOk = 0;
  }

}

skip:
// Check if $uploadOk is set to 0 by an error
if ($uploadOk == 0) 
{
  echo "<br><br>Error, your file was not uploaded.\r\n";
  // if everything is ok, try to upload file
} else {
  if (move_uploaded_file($_FILES["fileToUpload"]["tmp_name"], $target_file)) 
    {
    echo "<br>The file ". htmlspecialchars( basename( $_FILES["fileToUpload"]["name"])). " has been uploaded.";
     } else {
    echo "<br>Error, there was an error uploading your file.";
     }
 }
?>
