<?php
//
// This file will display the chart with datas for Power production
//
// Written By Autourdupc on 15 november 2024
//

//
// Called from UI

// V1.00 : original release
//


//we read the serverargument to find the way back
//$goBack = $_GET['page'];
$datum = $_GET['datum'];
//if($goBack == 0) {
//  echo '<a href="/index.php"><span class="close">&times;</span></a><br>';
//} else {
//  echo "<a href=../.".$goBack."><span class='close'>&times;</span></a><br>";
//}


// Check date
if ($datum == "undefined") $datum = date('Y-m-d');
$datum = isset($datum) ? $datum : date('Y-m-d');
$datum = !empty($datum) ? $datum : date('Y-m-d');
//$datum = checkdate(date_format($datum,'m'),date_format($datum,'d'),date_format($datum,'Y')) ? $datum : date('Y-m-d');

// We need to set the timezone = ok
include 'setTimezone.php';
$tz = date_default_timezone_get();

$startDate = new DateTime("$datum");
$startDate = $startDate->format("Y-m-d 03:0:0");
$endDate = new DateTime("$datum");
$endDate = $endDate->format("Y-m-d 23:0:0");


// Convert dates in timestamps ISO8601
$startDateISO = date('c', strtotime($startDate));
$endDateISO = date('c', strtotime($endDate));


// Define polling duration for the day
$json = file_get_contents("/var/www/ecu_data/settings.json");
$jsondata = json_decode($json);
$latitude = $jsondata->{'latitude'};
$longitude = $jsondata->{'longitude'};
$offset = $jsondata->{'offset'};
$sun_info = date_sun_info(strtotime($datum), $latitude, $longitude);
$poll_start = $sun_info['sunrise'] - abs($offset)*60;                          // Poll starts 5 min before sunset
$poll_end = $sun_info['sunset'] + abs($offset)*60;                          // Poll starts 5 min before sunset


// Datas for database connection
require '/usr/lib/cgi-bin/ecu/vendor/autoload.php';
$host = "127.0.0.1";
$port = "8086";
$dbname= "invData";

use InfluxDB\Client;

// Create InfluxDB client
$client = new Client($host, $port);

// Select database
$database = $client->selectDB('invData');


// Get the count of inverters
// --------------------------

// Read the file invCount.txt
$fp = fopen('/var/www/ecu_data/inverterCount.txt', 'r');
$invCount = (int)fgetc($fp);
fclose($fp);

// Pick the available inverters
$InverterCount=0;
for ( $x=0; $x < $invCount; $x++ )
    {
    $filename="/var/www/ecu_data/inverters/invProperties" . $x;
    if (file_exists($filename)) $InverterCount++;
    }
// Now $InverterCount contains the count of inverters
// i.e if count=2, there are 2 inverters


// Create the query
$from="";
for ($i=0 ; $i < $InverterCount ; $i++)
    {
    $from = $from."inv".$i.",";
    }
$from = substr($from, 0, -1);

// This query provides all the values for each inverters, so we got # values x inverter qty
// i.e : if we got 10 points per day and got 3 inverters, we got 10 * 3 = 30 points
$query = "SELECT FIRST(p) as p FROM ".$from." WHERE time >= '$startDateISO' AND time <= '$endDateISO' GROUP BY time(5m)";
//echo $query."<br>";


// Get the values
$result = $database->query($query);
$points = $result->getPoints();

//var_dump($points);
// Count the qty of total collected data in the array
$nb = count($points);
//echo "<br>Points : ".$nb."<br>";
//echo "Inverters : ".$InverterCount."<br>";

$total_p_now = 0;  // The actual power
$total_p_max = 0;  // The peak power
$prev_total_p = 0; // The previous total powr for all inverters at a specific timestamp
$sum_p = 0;        // SUM all power data

// Get the range = count points / count inverters
$range = $nb/$InverterCount;
//echo "Range : ".$range."<br>";
$Previous_timestamp = 0;   // Used for displaying live power

// We now collect power data for each inverters and do the calculations
for ($i=0; $i < $range ; $i++)
    {
    $total_p=0;     // total power for all inverters at a specific time
    $timestamp = date('c', strtotime($points[$i]["time"]));

    // SUM the power of each inverters
    for ($j=0 ; $j < $InverterCount ; $j++)
        {
        $index = $i+$j*$range;

        // Read teh power value for the selected inverter
        $value = isset($points[$index]["p"]) ? floatval($points[$index]["p"]) : 0;

        // Sometimes there are missing values due to inverter no response so we create the missing point by making
        //  the average with the previous and the next point only if next point is not null
        if ($value == 0)
           {
           if (floatval($points[($index+1)]["p"])> 0) $value = (floatval($points[($index-1)]["p"])+floatval($points[($index+1)]["p"]))/2;
           }
        // SUM the power value for each inverters
        $total_p += $value;
        $sum_p += $total_p;
        // Search for the max power production
        if ($total_p > $total_p_max)
           {
           $total_p_max = $total_p;
           $time_p_max = substr($timestamp,11,5);
           }
        // Get the actual power
        if ((strtotime($timestamp) > (time()-250)) && (strtotime($timestamp) < (time()+250)))
           {
           $total_p_now = $prev_total_p;
           $timestamp_p_now = $prev_timestamp;
           $time_p_now = substr($prev_timestamp,11,5);
           }
        }
    // Store the previous total power and timestamp for all the inverters for this specific timestamp
    $prev_total_p = $total_p;
    $prev_timestamp = $timestamp;

    // Create the final array
    $results_labels[] = substr($timestamp,11,5);
    $results[] = $total_p;
    }

// Create JSON data for chart
$Labels_Json = json_encode($results_labels);
$Data_Json = json_encode($results);

// Create texts to display
$PeakPower=round($total_p_max,0)." watt at ".$time_p_max;
if ($sum_p != 0) $PeakPower_tbl = "<tr><td align='right'>Peak power : </td><td>".$PeakPower."</td></tr>";

// Calculate whole poll day duration
$poll_diff = $sun_info['sunset'] - $sun_info['sunrise'] + 2*abs($offset)*60;  // Poll start 5 min before & ends 5 min after
$poll_day_duration = gmdate("H:i:s", $poll_diff);                             // Duration of the whole polling process for the day
$poll_day_duration_tbl = "<tr><td align='right'>Polling duration : </td><td>".$poll_day_duration."</td></tr>";


// Test if the chart is same day as today
$today = date_create(date("Y-m-d"));
$chartday = date_create($datum);
$diff = date_diff($today,$chartday);
if ($diff->format("%R%a") == 0)     // We are the same day as today
   {
//   $poll_diff = strtotime($timestamp_p_now) - $poll_end;
   $timestamp_p_now_str = strtotime($timestamp_p_now);
   if (($timestamp_p_now_str - $poll_end) < 0 && ($timestamp_p_now_str - $poll_start) > 0)  // If we are during polling period
//   if ($poll_diff < 0)     // If we are during polling time
      {
      // Calculate live power
      $LivePower=round($total_p_now,0)." watt";
      $LivePower.=($total_p_now !=0) ? " at ".$time_p_now:"";
      $LivePower_tbl = "<tr><td align='right'>Live power : </td><td>".$LivePower."</td></tr>";

      // Calculate actual poll duration
      $poll_diff = $timestamp_p_now_str - $poll_start;            // Calculate time between poll_start and now
      $poll_duration = gmdate("H:i:s", $poll_diff);               // Duration of the actual polling process duration
      $poll_duration_tbl = "<tr><td align='right'>Live polling duration : </td><td>".$poll_duration."</td></tr>";
      }
   }
   else     // We are not the same day as today
   {
   // Calculate poll duration
   $poll_duration = $poll_day_duration;
   }

/*
// Calculate average power
$range_duration = 24; //$poll_diff/24;                                // Duration / poll cycle duration (5 min) -> Give points count
$average_p = round($sum_p/$range_duration);
$poll_duration_tbl
$average_p_tbl = "<tr><td align='right'>Average power : </td><td>".$average_p." watt</td></tr>";

echo strtotime($timestamp_p_now)." - ".$poll_start."<br>";
echo $sum_p."/".$range_duration;
echo $sum_p."/".$range;
*/


?>
<!DOCTYPE>
<html>
    <head>
        <meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
        <meta name="theme-color" content="white"/>
        <title>RPI-ECU</title>
        <meta http-equiv="refresh" content="112">
        <meta name="viewport" content="width=device-width, initial-scale=1">
        <link rel="icon" type="image/x-icon" href="/favicon.ico" />
        <link rel="stylesheet" type="text/css" href="/STYLESHEET.css">
        <link rel="stylesheet" type="text/css" href="/STYLESHEET2.css">

        <style type="text/css">
        .chart-container {
                 width: 98%;
                 height: auto;
                 border: 1px solid;
                 background: white;
                 font-color: yellow;
                }
        canvas {
               width:98% !important;
               height:42vh !important;
               }
        @media screen and (max-width: 800px) {
                   canvas {
                          height:250px !important;
                          }
                   }
        @media screen and (max-width: 800px) and (orientation: landscape) {
                   canvas {
                          height:300px !important;
                          }
                   }
        table tr {
               color: black;
               font-size: 14px;
               padding: 0px 0px 0px 0px;
               border-spacing : 0px;
               height : 16px;
               }

        .close {
               color: red;
               float: right;
               font-size: 58px;
               font-weight: bold;
               cursor: pointer;
               padding: 0px 20px 0px 0px; /* trbl */
               }
        .close:hover {color: green;}
        </style>


        <script>
        function submitFunction(b) {
           var terug = "lbo_chart_p.php?datum=" + b;
           spinner();
           document.getElementById('formulier').submit();
           setTimeout(function(){window.location.href=terug;}, 3000 );
           }

       function spinner(){
           document.getElementById('loaderdiv').style.visibility = 'visible';
           }
       </script>
    </head>

    <body>
      <script type="text/javascript" src="chart.min.js"></script>
      <script type="text/javascript" src="jquery.min.js"></script>
      <div id='loaderdiv'><div class='loader'></div></div>
      <div id='msect'><center>
      <?php
      echo "<div class='divstijl' style='height: 100%;'><center>";
      if($goBack == 0) {
        echo '<a href="/index.php"><span class="close">&times;</span></a><br>';
      } else {
        echo "<a href=../.".$goBack."><span class='close'>&times;</span></a><br>";
      }
      echo '<form id="formulier" action="./lbo_chart_p.php">';
      echo"<input type='date' onchange='submitFunction(" . $goBack . ")' name='datum' value='" . $datum . "' style='width: 180px;' >";
      echo "</input></form>";
      echo "<table border=0>";
      echo $PeakPower_tbl;
      echo $LivePower_tbl;
      echo $average_p_tbl;
      echo $poll_duration_tbl;
      echo $poll_day_duration_tbl;
      echo "</table>";
      ?>
             <div class="chart-container">
                 <canvas id="PowerChart"></canvas>
            </div>
        </div>
      </div>
        <script>
            var ctx = document.getElementById('PowerChart').getContext('2d');
            var chart = new Chart(ctx, {
                // The type of chart we want to create
                type: 'line',

                // The data for the dataset
                data: {
                    labels: <?php echo $Labels_Json; ?>,
                    datasets: [{
                        label: "Production (W)",
                        fill: true,
                        backgroundColor: 'rgba(54, 162, 235, 0.2)',
                        borderColor: 'rgb(54, 162, 235)',
                        borderWidth: 2,
                        pointRadius: 1,
                        hitRadius: 10,
                        intersect: false,
                        pointBackgroundColor: 'rgb(54, 162, 235)',
                        pointHoverBackgroundColor: '#fff',
                        pointHoverBorderColor: 'rgb(54, 162, 235)',
                        data: <?php echo $Data_Json; ?>,
                    }]
                },

                // Configuration options go here
                options: {
                         responsive: true,
                         maintainAspectRatio: false,
                             scales: {
                                     y: {
                                        title: {
                                               display: true,
                                               color: 'blue',
                                               text: 'watt'
                                               },
                                        grid:  {
                                               color: 'lightgrey'
                                               },
                                        ticks: {
                                               color: 'blue',
                                               }
                                        }//end y:
                                     }, <!-- end_scales -->

                             plugins: {
                                      legend: {
                                              display: false
                                              },

                                      title: {
                                             display: true,
                                             color: 'rgb(54, 162, 235)',
                                             text: "Power production",
                                             font: {
                                                   size: 18
                                                   },
                                             }, <!-- end_title -->
                                      } <!-- end_plugins -->
                         } <!-- end_options -->
            });
        </script>
    <br><center><iframe name='hiddenFrame' width='420' height='100' hidden ></iframe>
    </body>
</html>
