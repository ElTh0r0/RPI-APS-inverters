<?php
echo "running test.php";
// we read the file // var/www/ecu_data/timezone.txt

$file="/var/www/ecu_data/timezone.txt";
if(file_exists($file)){
$fp = fopen($file, 'r');
$tz = fgets($fp);
echo "file exists value timezone = " . $tz . "\n<br>";
fclose($fp);
} else {
echo "no timezone file<br>\n";
}

//echo "query the php default tz: <br>\n";
// we know this is always UTC
//$tz = date_default_timezone_get();
//echo "php default tz = " . $tz . "<br>\n";


echo "calling setTimezone.php<br>\n";
include 'setTimezone.php';

$tz = date_default_timezone_get();
//}
echo "tz now = " . $tz ."<br>\n";
?>