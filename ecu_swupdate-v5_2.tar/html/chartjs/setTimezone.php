<?php
/* 
The php default systemtime is always timezone UTC so we have to adapt this to our local system time.
This function is called whenever the php time needs to be set.
It reads the timezone from the timezonefile and
puts this in the date_default_timezone
*/

$file="/var/www/ecu_data/timezone.txt";
if(file_exists($file)){
$fp = fopen($file, 'r');
$tz = fgets($fp);
$trimmed=ltrim($tz,"Timezone=");
fclose($fp);
// remove the newline character
$trimmed=str_replace("\n","",$trimmed);

} else {
$trimmed = "Europe/Berlin";
// if there is no file we fall back on berlin
}

date_default_timezone_set($trimmed);

?>