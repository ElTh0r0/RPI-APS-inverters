<!DOCTYPE html><html><head><meta charset='utf-8'>
<title>RPI-ECU-ANALYSIS</title>
<meta name="viewport" content="width=device-width, initial-scale=1">
<link rel="shortcut icon" type="image/png" href="/favicon.ico"/>
<link rel="stylesheet" type="text/css" href="/STYLESHEET.css">
<link rel="stylesheet" type="text/css" href="/STYLESHEET2.css">
<style>
.butt {
  font-size:26px; 
  heigth:34px;
    border: 2px solid black;
  border-radius:6px;
  
}
tr {height:30px !important;}

</style>
</head>
<body>
<div id='loaderdiv'><div class='loader'></div></div>
<div id='msect'><center>
<script>
function submitFunction(a) {
var terug = "ANALYZE.php?inv=" + a; 
spinner();
document.getElementById('formulier').submit();
//setTimeout(function(){window.location.href='ANALYZE.php';}, 2000 ); 

setTimeout(function(){window.location.href=terug;}, 2000 ); 

}
function helpfunctie() {
document.getElementById("help").style.display = "block";
}
function sl() {  
document.getElementById("help").style.display = "none";
}
function spinner(){
document.getElementById('loaderdiv').style.visibility = 'visible';
}


</script>
<div id='help'>
  <span class='close' onclick='sl();'>&times;</span><h3>ANALYSIS HELP</h3>
  <b>purpose:</b><br>
  With this tool you can retrieve some statistical data over a chosen period.
  <br><br><b>begin- and enddata</b><br>The period is including the begin and enddate.<br><br><strong>Please note: </strong>You cannot query the present day, as this data is not yet in the database. 
   <br><br>

</div>

<div id='menu'>
  <a id='fleft' href='#' onclick='helpfunctie()'>help</a>

<?php
 
$invnr = $_GET['inv'];

echo '<a class="close" href="/ANALYZE.php?inv=' . $invnr . '">&times;</a></div>';

//echo "</div>";

echo"<kop>statistical analysis over a period</kop><div class='divstijl'><center><h3>define the period</h3>";

echo "<form id='formulier' method='post' action='writeQuerydates.php' target='hiddenFrame'>";
echo "<table style='border: 1px solid black;'>";
//first we read the start and enddate in customQdate.txt

$file="/var/www/ecu_data/customQdate.txt";
if(file_exists($file)){
$fp = fopen($file, 'r');
$dat = fgets($fp);
$Bdatum = new DateTime("$dat");
$Bdatum = $Bdatum->format("Y-m-d");
$dat = fgets($fp);
$Edatum = new DateTime("$dat");
$Edatum = $Edatum->format("Y-m-d");
fclose($fp);
}
// put the dates in the selects
echo "<tr><td><label for='startDate'><h3>from:</h3></label>";
echo "<td><input type='date' id='startDate' name='startDate' min='2021-11-30' value='" . $Bdatum . "'></input><br>";
echo "<tr><td><label for='endDate'><h3>to:</h3></label>";
echo "<td><input type='date' id='endDate' name='endDate' min='2021-11-30' value='" . $Edatum . "'></input><br>";

/*
now the select for which inverter, this can be skipped, we use
the inverter from /ramdisk/invChoice
*/

echo "</table></select></form><br>";

echo "<button class='butt' onclick='submitFunction(" . $invnr . ")'>query</button><br>";
?>

<iframe name='hiddenFrame' width='420' height='300' hidden></iframe>  


</table>

</body>
</html>
