#!/bin/bash
    echo "running setStatic_data.sh<br>"
# we run this script as sudo so we set permissions in sudoers
if [[ -d /var/www/static_data ]] ; then
    echo "var/www/static_data exists<br>"
else
    echo "creating directory /var/www/static_data <br>"
    mkdir /var/www/static_data
    echo "creating var/www/static_data/swVersion.txt <br>"
    echo "RPI_ECU-v4_5" > /var/www/static_data/swVersion.txt
    echo "creating var/www/static_data/fs_size.txt <br>"
    echo "/dev/root        3G  3.6G   11G  25% /" > /var/www/static_data/fs_size.txt
    echo "creating var/www/static_data/expand.txt <br>"
    echo "n" > /var/www/static_data/expand.txt

    # now set permissions on these files
    chmod -R a+rw /var/www/static_data/
fi
